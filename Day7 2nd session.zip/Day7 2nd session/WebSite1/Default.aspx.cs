﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //if(base.IsPostBack)
        //if(IsPostBack)
        //if(this.Page.IsPostBack)
        //if(Page.IsPostBack)
        //if(base.Page.IsPostBack)
        //if (this.IsPostBack == false)
        if (!IsPostBack)
        {
            Label1.Text = "Page loaded for the first time";
            ViewState["count"] = 0;
        }
        else
        {
            Label1.Text = "Page loaded due to a PostBack";
            ViewState["count"] = ((int)ViewState["count"]) + 1;
        }
        Label2.Text = ViewState["count"].ToString();
        Label3.Text = "Visitors : " + Application["count"].ToString();
    }
    
    protected void Button1_Click(object sender, EventArgs e)
    {
        //server controls
        txtFullName.Text = txtFirstName.Text + " " + txtLastName.Text;
        txtFullName.Text = Request.Form["txtFirstName"] + " " + Request.Form["txtLastName"];
        
        //html controls
        txtFullName.Text = Request.Form["Text1"] + " " + Request.Form["Text2"]; ;

        //html controls with runat="server"
        txtFullName.Text = Text3.Value + Text4.Value;
        txtFullName.Text = Request.Form["Text3"] + " " + Request.Form["Text4"]; ;
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Server.Transfer("Default2.aspx");
    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        //Response.Redirect("Default2.aspx?firstname=" + txtFirstName.Text);
        Response.Redirect("Default2.aspx?firstname=" + txtFirstName.Text 
            + "&lastname=" + txtLastName.Text);

    }
    protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
    {
        HttpCookie objCookie = new HttpCookie("ChocoChip");
        //storing only one value in the cookie
        //objCookie.Value = txtFirstName.Text;
        
        //storing multiple values in the cookie
        objCookie.Values["firstname"] = txtFirstName.Text;
        objCookie.Values["lastname"] = txtLastName.Text;

        
        objCookie.Expires = DateTime.Now.AddDays(1);

        Response.Cookies.Add(objCookie);
        Response.Redirect("Default2.aspx");

    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        Session["firstname"] = txtFirstName.Text;
        Response.Redirect("Default2.aspx");
    }
    public TextBox TextBoxFirstName
    {
        get { return txtFirstName; }
    }
    protected void txtFirstName_TextChanged(object sender, EventArgs e)
    {
        txtFullName.Text = txtFirstName.Text + txtLastName.Text;
    }
}