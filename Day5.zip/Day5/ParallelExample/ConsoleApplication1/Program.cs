﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main1()
        {
            Parallel.Invoke(Method1, Method2, Method3,Method4);
            Console.ReadLine();
        }
        static void Method1()
        {
            Console.WriteLine("M1");

        }
        static void Method2()
        {
            Console.WriteLine("M2");
        }
        static void Method3()
        {
            Console.WriteLine("M3");
        }
        static void Method4()
        {
            Console.WriteLine("M4");
        }
        static void Main()
        {
            Parallel.For(0, 10, DoSomething);
            Console.ReadLine();
        }
        static void DoSomething(int i)
        {
            Console.WriteLine(i);
        }
        static void Main3()
        {
            List<Employee> objEmps = new List<Employee> { new Employee { Name = "a", EmpNo = 1 }, new Employee { Name = "v", EmpNo = 2 } };
            Parallel.ForEach<Employee>(objEmps, emp => { Console.WriteLine(emp.Name); });
            Parallel.ForEach<Employee>(objEmps, ProcessEmployee);
            Console.ReadLine();
        }

        static void ProcessEmployee(Employee obj)
        {
            Console.WriteLine(obj.Name);
        }
        static void Main4()
        {
            List<Employee> objEmps = new List<Employee> { new Employee { Name = "a", EmpNo = 1 }, new Employee { Name = "v", EmpNo = 2 } };

            var emps = objEmps.Where(emp => emp.EmpNo > 0).AsParallel();
            var emps2 = objEmps.Where(emp => emp.EmpNo > 0).AsParallel().WithDegreeOfParallelism(2);
            objEmps.Where(emp => emp.EmpNo > 0).AsParallel().ForAll(emp => { Console.WriteLine(emp.Name); });


            Console.ReadLine();
        }
        
    }
    public class Employee
    {
        public int EmpNo;
        public string Name;
    }
}
