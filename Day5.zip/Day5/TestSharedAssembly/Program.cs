﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestSharedAssembly
{
    class Program
    {
        static void Main()
        {
            CDACSharedAssembly.Class1 o = new CDACSharedAssembly.Class1();
            Console.WriteLine(o.Hello());


        }
    }
}
