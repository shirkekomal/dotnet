﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main()
        {
            //CallAsyncTask();
            Task t = CallAsyncTask();
            Console.WriteLine("done");
            t.Wait();
            Thread.Sleep(9000);
            //Console.ReadLine();
        }
        //static async void CallAsyncTask()
        static async Task CallAsyncTask()
        {
            Console.WriteLine("Calling using await...");
            int i = await Task.Run(() => GetData());
            Console.WriteLine(i);
        }
        static int GetData()
        {
            Thread.Sleep(2000);
            return 1;
        }
    }
}
