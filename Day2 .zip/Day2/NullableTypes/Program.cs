﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NullableTypes
{
    class Program
    {
        static void Main()
        {
            int ? a = 100;
            a = null;
            int b=0;
            if (a == null)
                Console.WriteLine("null");
            else
                b = a.Value;

            if (a.HasValue)
                b = a.Value;
            else
                Console.WriteLine("null");
            b = a.GetValueOrDefault();
            b = a.GetValueOrDefault(10);
            Console.ReadLine();
        }
    }
}
