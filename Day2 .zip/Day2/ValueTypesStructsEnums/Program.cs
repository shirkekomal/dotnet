﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ValueTypesStructsEnums
{
    class Program
    {
        static void Main2()
        {
            //int a = 0;
            int a = new int();
            MyPoint p1;
            p1 = new MyPoint();

            MyPoint p2;
            p2.X = 0;
            p2.Y = 0;

            Console.ReadLine();
        }
    }
    //structs - value types
    //cannot have a no param constructor
    //no inheritance
    public struct MyPoint
    {
        public int X;
        public int Y;
        public MyPoint(int X, int Y)
        {
            //values must be initialised in constructor
            this.X = X;
            this.Y = Y;
        }
    }


    public class C1
    {
        static void Main()
        {
            DisplayGreeting(TimeOfDay.Morning);

        }

        static void DisplayGreeting(TimeOfDay time)
        {
            if (time == TimeOfDay.Morning)
                Console.WriteLine("Good Morning");
            else if (time == TimeOfDay.Afternoon)
                Console.WriteLine("Good Afternoon");
            else if (time == TimeOfDay.Evening)
                Console.WriteLine("Good Evening");
            else if (time == TimeOfDay.Night)
                Console.WriteLine("Good Night");
        }
    }
    //uses a constant instead of a value
    public enum TimeOfDay //: short
    {
        Morning = 100,
        //Morning,
        Afternoon,
        Evening = 200,
        Night
    }

}
