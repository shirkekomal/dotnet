﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EventHandling
{
    class Program
    {
        static void Main1()
        {
            C1 o = new C1();
            P1ChangedEventHandler objDel = new P1ChangedEventHandler(o_P1Changed);
            //pass the delegate object to the programmer
            //call objdel IF P1Changed event fires
            o.P1Changed += objDel;
            o.P1 = 100;
            Console.ReadLine();
        }
        static void o_P1Changed()
        {
            Console.WriteLine("P1 changed event fired");
        }

    }

    //step 1 : create a delegate class having the same signature as the event
    public delegate void P1ChangedEventHandler();
    public class C1
    {
        //step 2: declare event of delegate type
        public event P1ChangedEventHandler P1Changed;

        private int p1;
        public int P1
        {
            get { return p1; }
            set 
            { 
                p1 = value;
                //step 3: raise event whenever required
                P1Changed();
            }
        }

    }

}
namespace EventHandling1
{
    class Program
    {
        static void Main1()
        {
            C1 o = new C1();
            //P1ChangedEventHandler objDel = new P1ChangedEventHandler(o_P1Changed);
            //o.P1Changed += objDel;
            //o.P1Changed += new P1ChangedEventHandler(o_P1Changed);
            o.P1Changed += o_P1Changed;
            o.P1 = 100;
            Console.ReadLine();
        }
        static void o_P1Changed()
        {
            Console.WriteLine("P1 changed event fired");
        }

    }

    //step 1 : create a delegate class having the same signature as the event
    public delegate void P1ChangedEventHandler();
    public class C1
    {
        //step 2: declare event of delegate type
        public event P1ChangedEventHandler P1Changed;

        private int p1;
        public int P1
        {
            get { return p1; }
            set
            {
                p1 = value;
                //step 3: raise event whenever required
                P1Changed();
            }
        }

    }

}
namespace EventHandling2
{
    class Program
    {
        static void Main2()
        {
            C1 o = new C1();
            //one event could have multiple handlers
            o.P1Changed += o_P1Changed;
            o.P1Changed += func2;
            o.P1 = 100;
            Console.WriteLine();
            o.P1Changed -= func2;
            o.P1 = 200;



            Console.ReadLine();
        }
        static void o_P1Changed()
        {
            Console.WriteLine("event handled here");
        }
        static void func2()
        {
            Console.WriteLine("event also handled here");
        }


    }

    //step 1 : create a delegate class having the same signature as the event
    public delegate void P1ChangedEventHandler();
    public class C1
    {
        //step 2: declare event of delegate type
        public event P1ChangedEventHandler P1Changed;

        private int p1;
        public int P1
        {
            get { return p1; }
            set
            {
                p1 = value;
                //step 3: raise event whenever required
                P1Changed();
            }
        }

    }

}

namespace EventHandling3
{
    class Program
    {
        static void Main()
        {
            C1 o = new C1();
            //o.P1Changed += o_P1Changed;
            Console.WriteLine();
            o.P1 = 200;
            Console.ReadLine();
        }

        static void o_P1Changed(int newValue)
        {
            Console.WriteLine("P1 changed new value is "+ newValue);
        }

    }
    //step 1 : create a delegate class having the same signature as the event
    public delegate void P1ChangedEventHandler(int newValue);
    public class C1
    {
        //step 2: declare event of delegate type
        public event P1ChangedEventHandler P1Changed;

        private int p1;
        public int P1
        {
            get { return p1; }
            set
            {

                p1 = value;
                //step 3: raise event whenever required
                if(P1Changed !=null)
                    P1Changed(value);
            }
        }

    }

}
