﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AnonymousMethods
{
    class Program
    {
        static void Main()
        {
            //Action objDel = new Action(Display);
            //objDel();
            int i = 100;
            //variables declared in outer function can be accessed in the anonymous method
            Action objDel = delegate()
            {
                Console.WriteLine("disp called" + i);
                i++;
            };
            objDel();

            Console.WriteLine(i);

            Console.ReadLine();
        }
        static void Main2()
        {
            Func<int, int, int> objDel = delegate(int a, int b)
            {
                return a + b;
            };
            Console.WriteLine( objDel(10,20) );

            Console.ReadLine();
        }
        //static void Display()
        //{
        //    Console.WriteLine("disp called");
        //}
        //static int Add(int a, int b)
        //{
        //    return a + b;
        //}
    }
}
