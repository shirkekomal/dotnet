﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace LockingSynchronization
{
    class Program
    {
        static object lockobj = new object();
        static int i = 0;
        static void Main()
        {
            Thread t1 = new Thread(new ThreadStart(FuncLock));
            Thread t2 = new Thread(new ThreadStart(FuncMonitor));
            Thread t3 = new Thread(new ThreadStart(FuncInterLock));

            t1.Start();
            t2.Start();
            t3.Start();

            t1.Join();
            t2.Join();
            t3.Join();
            Console.WriteLine("Finished Main");
            Console.ReadLine();

        }

        static void FuncLock()
        {
            lock(lockobj)
            {
                i++;
                Console.WriteLine("First FuncLock " + i);
                i++;
                Console.WriteLine("First FuncLock " + i);
                i++;
                Console.WriteLine("First FuncLock " + i);
                i++;
                Console.WriteLine("First FuncLock " + i);
                i++;
                Console.WriteLine("First FuncLock " + i);
 
            }
        }
        
        static void FuncMonitor()
        {
            Monitor.Enter(lockobj);
            {
                i++;
                Console.WriteLine("Second Monitor "+i.ToString());
                 i++;
                Console.WriteLine("Second Monitor "+i.ToString());
                 i++;
                Console.WriteLine("Second Monitor "+i.ToString());
                 i++;
                Console.WriteLine("Second Monitor "+i.ToString());
                 i++;
                Console.WriteLine("Second Monitor "+i.ToString());
            }
            Monitor.Exit(lockobj);
        }

        static void FuncInterLock()
        {
            Interlocked.Add(ref i, 10);
            Console.WriteLine("Third Interlocked " + i.ToString());
            Interlocked.Decrement(ref i);
            Console.WriteLine("Third Interlocked " + i.ToString());
            Interlocked.Increment(ref i);
            Console.WriteLine("Third Interlocked " + i.ToString());
            Interlocked.Exchange(ref i, 100);
            Console.WriteLine("Third Interlocked " + i.ToString());
        }



    }
}
