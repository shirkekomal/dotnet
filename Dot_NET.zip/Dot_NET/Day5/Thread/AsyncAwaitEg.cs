﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace AwaikThread
{
    class AsyncAwaitEg
    {
        static void Main()
        {
            Task t1 = AsyncMethod();
            Console.WriteLine("Done");
            t1.Wait();
            Thread.Sleep(200);
        }

        static async Task AsyncMethod()
        {
            Console.WriteLine("await call");
            int i = await Task.Run(() => Display());
        }
    }

          static int Display()
        {
            return 1;
        }
}
