﻿using System;
using System.Threading;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AsyncCodeWithDelegates
{
    class Program
    {
        static void Main1()
        {
            Action ObjDel = Dispaly;
            Console.WriteLine("Before Threading");
            ObjDel.BeginInvoke(null,null);
            Console.WriteLine("After Threading");
            Console.ReadLine();

        }

        static void Dispaly()
        {
            Thread.Sleep(3000);
            Console.WriteLine("Display ");
        }
    }
}

namespace AsyncCodeWithDelegates2
{
    class Program
    {
        static void Main2()
        {
            Action<string> ObjDel = Dispaly;
            Console.WriteLine("Before Threading");
         ObjDel.BeginInvoke("Welcome",null ,null);
          
            Console.WriteLine("After Threading");
            Console.ReadLine();

        }

        static void Dispaly(String s)
        {
            Thread.Sleep(3000);
            Console.WriteLine("Display "+s);
        }
    }
}

namespace AsyncCodeWithDelegates3
{
    class Program
    {
        static void Main3()
        {
           Func<string,string> Objdel=Dispaly;
            Console.WriteLine("Before Threading");
            //Objdel.BeginInvoke("Welcome ",new AsyncCallback(callBackFunction),Objdel);
            Objdel.BeginInvoke("Welcome ",callBackFunction,Objdel);
            Console.WriteLine("After Threading");
            Console.ReadLine();

        }

        static string Dispaly(String s)
        {
            Thread.Sleep(3000);
            Console.WriteLine("Display " + s);
            return s.ToUpper();
        }


        static void callBackFunction(IAsyncResult a)
        {
            Console.WriteLine("CAllBAck Function");
            Func<string,string> Obj= (Func<string,string>)a.AsyncState;
            Console.WriteLine("Result "+ Obj.EndInvoke(a));
         
        }
    }
}

namespace AsyncCodeWithDelegates3
{
    class Program1
    {
        static void Main4()
        {
            Func<string, string> Objdel = Dispaly;
            Console.WriteLine("Before Threading");
            //Objdel.BeginInvoke("Welcome ",new AsyncCallback(callBackFunction),Objdel);
           
            Objdel.BeginInvoke("Welcome ", delegate(IAsyncResult a)
        {
            Console.WriteLine("CAllBAck Function");
           // Func<string, string> Obj = (Func<string, string>)a.AsyncState;
            Console.WriteLine("Result " + Objdel.EndInvoke(a));

        },null);
            Console.WriteLine("After Threading");
            Console.ReadLine();

        }

        static string Dispaly(String s)
        {
            Thread.Sleep(3000);
            Console.WriteLine("Display " + s);
            return s.ToUpper();
        }


       
    }
}

namespace  AsyncCodeWithThread
{
    public class Prog
    {
        static void Main5()
        {
            Thread t = new Thread(Func1);
            Thread t1 = new Thread(Func2);
            t1.IsBackground = false;
            t.IsBackground = false;
            t1.Priority = ThreadPriority.Highest;
            t.Priority = ThreadPriority.Lowest;
            Thread.CurrentThread.Priority = ThreadPriority.Normal;

            t1.Start();
            t.Start();
            for(int i=0;i<100;i++)
            {
   
                Console.WriteLine("Main Thread-->>"+i);
            }
         

           // Console.ReadLine();
            //t.Join();
            //t1.Join();
            //t.Abort();
        }

        static void Func1()
        {
            
            for(int i=0;i<200;i++)
            {
                Console.WriteLine("First Thread-->>"+i.ToString());
            }
        }

        static void Func2()
        {
           
            for (int i = 0; i < 200; i++)
            {
                Console.WriteLine("Second Thread-->>" + i.ToString());
            }
        }
    }
}

namespace ThreadParam
{
    class prog2
    {
        static void Main6()
        {
            Thread t2 = new Thread(Func3);
            t2.Start(1000);
        }
        static void Func3(object o)
        {
            Console.WriteLine("Function3");
            Console.WriteLine(o);
        }
    }
}

namespace ThreadPool1
{
    class prog3
    {
        static void Main8()
        {
            ThreadPool.QueueUserWorkItem(Func1);
            ThreadPool.QueueUserWorkItem(Func31, new { EmpName = "komal",EmpNo=1});
            Console.ReadLine();
            
        }
        static void Func31(object o)
        {
            Thread.Sleep(3000);
            Console.WriteLine(o);
        }

        static void Func1(object o)
        {
            Thread.Sleep(4000);
            Console.WriteLine("Func1 ");
        }
       
    }

    //public class Employee
    //{
    //    public int EmpNo=1;
    //    public string EmpName="komal";
    //    public override string ToString()
    //    {
    //        return "EmpNo-->>" + EmpNo +" "+ "EmpName-->>" + EmpName;
    //    }
    //}
}

namespace AsyncCodeWithTask
{
    class Program
    {

        static void Main9()
        {
            Task t1 = new Task(Func1);
            Task t2 = new Task(Func2);
            // Task t3 = Task.Factory.StartNew(Func3);
            t1.Start();
            t2.Start();
            for (int i = 0; i < 100; i++)
            {
                Console.WriteLine("main:" + i);
            }
            Console.ReadLine();

        }
        static void Func1()
        {
            for (int i = 0; i < 100; i++)
            {
                Console.WriteLine("First:" + i);
            }
        }
        static void Func2()
        {
            for (int i = 0; i < 100; i++)
            {
                Console.WriteLine("Second:" + i);
            }
        }
    }
}

namespace AsyncCodeWithTaskwithReturnVal
{
    class Program
    {

        static void Main10()
        {
            Task<int> t1 = new Task<int>(Func1);
            t1.Start();
            Console.ReadLine();

        }
        static int Func1()
        {
            Thread.Sleep(100);
            Console.WriteLine("Func1");
            return 1;
        }
     
    }
}

namespace AsyncCodeWithTaskwithParam
{
    class Program
    {

        static void Main()
        {
            Task<int> t1 = new Task<int>(Func1, 10);
            t1.Start();
            Console.ReadLine();

        }
        static int Func1(object o)
        {
            Thread.Sleep(100);
            Console.WriteLine("Func1-----");
            return 1;
        }

    }
}

