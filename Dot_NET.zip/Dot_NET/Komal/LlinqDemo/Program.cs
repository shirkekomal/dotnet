﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LinqType
{
    class Employee
    {
        private int empNo;

        public int EmpNo
        {
            get { return empNo; }
            set { empNo = value; }
        }

        private string empName;

        public string EmpName
        {
            get { return empName; }
            set { empName = value; }
        }

        private decimal basic;

        public decimal Basic
        {
            get { return basic; }
            set { basic = value; }
        }
    }
   
    
   class LINQS
    {


        static void Main()
        {
            //collection initializer

            List<Employee> lstEmployee;
            lstEmployee = new List<Employee>
             {
                 new Employee{EmpNo=1,EmpName="komal",Basic=12000},
                 new Employee{EmpNo=2,EmpName="Shirke",Basic=20000},
                 new Employee{EmpNo=3,EmpName="KK",Basic=30000},
                 new Employee{EmpNo=4,EmpName="KKK",Basic=40000},
                 new Employee{EmpNo=3,EmpName="KK",Basic=30000},
                 new Employee{EmpNo=4,EmpName="KKK",Basic=40000},
              };
            lstEmployee.Add(new Employee { EmpNo = 5, EmpName = "Abhi", Basic = 11000 });
            lstEmployee.Add(new Employee { EmpNo = 6, EmpName = "Kiran", Basic = 15000 });



            var emps = from emp in lstEmployee select emp;
            Console.WriteLine("-----------------------1----------------------");
            foreach (var item in emps)
            {
                Console.WriteLine(" EmpNo-->> " + item.EmpNo + " EmpName-->> " + item.EmpName + " BasicSal-->> " + item.Basic);
                Console.WriteLine("                                                     ");
            }

            Console.WriteLine("----------------------2-----------------------");
            var emps1 = from emp in lstEmployee select new { emp.EmpNo, emp.EmpName };
            foreach (var item in emps1)
            {
                Console.WriteLine("EmpNo-->>" + item.EmpNo + "EmpName-->>" + item.EmpName);
                Console.WriteLine("                                                     ");
            }

            Console.WriteLine("---------------------3------------------------");
            var emps2 = from emp in lstEmployee where emp.Basic > 10000 select emp;
            foreach (var item in emps2)
            {
                Console.WriteLine("EmpNo-->> " + item.EmpNo + "EmpName-->> " + item.EmpName + "BasicSal-->> " + item.Basic);
                Console.WriteLine("                                                     ");
            }

            Console.WriteLine("--------------------------4-------------------");
            var emps3 = from emp in lstEmployee
                        where emp.Basic > 10000 && emp.EmpName.StartsWith("K")
                        select emp;
            foreach (var item in emps3)
            {
                Console.WriteLine("EmpNo-->> " + item.EmpNo + "EmpName-->> " + item.EmpName + "BasicSal-->> " + item.Basic);
                Console.WriteLine("                                                     ");
            }

            Console.WriteLine("-----------------------5----------------------");
            var emps4 = from emp in lstEmployee
                        where emp.Basic > 10000 || emp.EmpName.EndsWith("K")
                        select emp;
            foreach (var item in emps4)
            {
                Console.WriteLine("EmpNo-->> " + item.EmpNo + "EmpName-->> " + item.EmpName + "BasicSal-->> " + item.Basic);
                Console.WriteLine("                                                     ");
            }
            Console.WriteLine("-----------------------6----------------------");
             var emps5 = from emp in lstEmployee
                       orderby emp.EmpName,emp.EmpNo,emp.Basic
                       select emp;

            foreach(var item in emps5 )
            {
                  Console.WriteLine("EmpNo-->> " + item.EmpNo + "EmpName-->> " + item.EmpName + "BasicSal-->> " + item.Basic);
                Console.WriteLine("                                                     ");
            }
            Console.WriteLine("-----------------------7----------------------");


            var emps6 = from emp in lstEmployee
                       orderby emp.EmpName descending, emp.EmpNo, emp.Basic ascending
                       select emp;


            foreach (var item in emps6)
            {
                Console.WriteLine("EmpNo-->> " + item.EmpNo + "EmpName-->> " + item.EmpName + "BasicSal-->> " + item.Basic);
                Console.WriteLine("                                                     ");
            }
            Console.WriteLine("-----------------------8----------------------");


            var emps7= lstEmployee.Select(emp => emp);


            foreach (var item in emps6)
            {
                Console.WriteLine("EmpNo-->> " + item.EmpNo + "EmpName-->> " + item.EmpName + "BasicSal-->> " + item.Basic);
                Console.WriteLine("                                                     ");
            }
            Console.WriteLine("---------------------9------------------------");

            var emps8 = lstEmployee.GroupBy(emp=>emp.Basic).Select(emp => emp);


            foreach (var item in emps6)
            {
                Console.WriteLine("EmpNo-->> " + item.EmpNo + "EmpName-->> " + item.EmpName + "BasicSal-->> " + item.Basic);
                Console.WriteLine("                                                     ");
            }

            Console.WriteLine("---------------------10------------------------");

            var emps9 = lstEmployee.Where(emp=>emp.Basic>20000).GroupBy(emp=>emp.Basic).Select(emp => emp);
            
            foreach (var item in emps6)
            {
                Console.WriteLine("EmpNo-->> " + item.EmpNo + "EmpName-->> " + item.EmpName + "BasicSal-->> " + item.Basic);
                Console.WriteLine("                                                     ");
            }
            }       
        }

    }
