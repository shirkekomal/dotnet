﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DelegateDemo
{

    class FuncDelegate
    {
        static int sum(int a,int b)
        {
            return a + b;

        }

        static string Dosome(string a, float b)
        {
            return a;
        }

        static void Main15()
        {
            Func<int, int, int> fc = new Func<int, int, int>(sum);
            Console.WriteLine("Sum "+ fc(10, 20));
            Func<string, float, string> f = Dosome;
            Console.WriteLine("Name-->>"+f("komal", 10));
        }
    }
}
