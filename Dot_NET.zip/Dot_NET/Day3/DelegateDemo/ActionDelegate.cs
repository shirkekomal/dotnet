﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DelegateDemo
{
     
   // public delegate void DelDisp();

    class ActionDelegate
    {

        static void Main24()
        {
          //  DelDisp d = Display;
          //  d();

            //Action a = Display;
            //a();

            //Action<String> a = new Action<string>(Display);
            //a("Komal");

            Action<string, int, float> a = Display;
            a("komal", 12, 12.2f);
        }
      
        static void Display()
        {

            Console.WriteLine("Display");
        }

        static void Display(String s)
        {

            Console.WriteLine("Display  "+s);
        }

        static void Display(String s,int i,float c)
        {

            Console.WriteLine("Name " + s+"\n"+"Id "+i+"\n"+"Sal "+c);
        }
    }

   
     
}
