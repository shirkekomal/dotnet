﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise_Day3
{
    public struct Employee
    {
        public int empId;
        public String empName;
        public short sal;
    }


    class Program
    {
        
        static void Main1(string[] args)
        {
            Employee emp = new Employee();
            emp.empId = 1;
            emp.empName = "komal";
            emp.sal = 3;
            Predicate<Employee> e = SalFun;
            bool ss=e(emp);
            if(ss)
                Console.WriteLine("Salary-->>"+emp.sal);
            else
                Console.WriteLine("salary is less than 10000");

            Console.ReadLine();
        }

        static bool SalFun(Employee e)
        {
            return (e.sal > 10000);
        }
    }
}
