﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class DataList : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            SqlConnection cn = new SqlConnection(@"Data Source=(localdb)\Projects;Initial Catalog=koko;Integrated Security=True;");
            cn.Open();

            SqlCommand cmd = new SqlCommand();
            cmd.Connection = cn;
            cmd.CommandText = "select * from Departments";

            SqlDataAdapter da = new SqlDataAdapter();
            da.SelectCommand = cmd;

            DataSet ds = new DataSet();
            da.Fill(ds, "Deps");

            cmd.CommandText = "select * from Employees";
            da.Fill(ds, "Emps");

            Session["ds"] = ds;

            DataList1.DataSource = ds.Tables["Emps"];
            DataList1.DataBind();
        }

    }
    protected void Edit(object source, DataListCommandEventArgs e)
    {
        DataSet ds = (DataSet)Session["ds"];
        DataList1.EditItemIndex = e.Item.ItemIndex;
        DataList1.DataSource = ds.Tables["Deps"];
        DataList1.DataBind();
    }


    protected void Update(object source, DataListCommandEventArgs e)
    {
        DataSet ds = (DataSet)Session["ds"];
        TextBox t1 = (TextBox)e.Item.FindControl("TextBox1");


        DataList1.DataSource = ds.Tables["Deps"];
        DataList1.DataBind();
    }
}