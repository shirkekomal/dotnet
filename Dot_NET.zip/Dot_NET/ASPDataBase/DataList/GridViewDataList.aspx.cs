﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class GridViewDataList : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            SqlConnection cn = new SqlConnection(@"Data Source=(localdb)\Projects;Initial Catalog=koko;Integrated Security=True;");
            cn.Open();

            SqlCommand cmd = new SqlCommand();
            cmd.Connection = cn;
            cmd.CommandText = "select * from Departments";

            SqlDataAdapter da = new SqlDataAdapter();
            da.SelectCommand = cmd;

            DataSet ds = new DataSet();
            da.Fill(ds, "Deps");

            cmd.CommandText = "select * from Employees";
            da.Fill(ds, "Emps");

            Session["ds"] = ds;

            DataList1.DataSource = ds.Tables["Emps"];
            DataList1.DataBind();
        }
    }
    protected void DataList1_ItemDataBound(object sender, DataListItemEventArgs e)
    {
        DataSet ds = (DataSet)Session["ds"];
        GridView grd = (GridView)e.Item.FindControl("GridView1");
        grd.DataSource = ds.Tables["Emps"];
        grd.DataBind();

    }
    protected void DataList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        
    }
    protected void GridView1_RowEditing(object sender, GridViewEditEventArgs e)
    {
        DataSet ds = (DataSet)Session["ds"];
        GridView grd = (GridView)DataList1.Items[0].FindControl("GridView1");
        grd.EditIndex = e.NewEditIndex;
        grd.DataSource = ds.Tables["Emps"];
        grd.DataBind();  
    }
    protected void GridView1_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        DataSet ds = (DataSet)Session["ds"];
        GridView grd = (GridView)DataList1.Items[0].FindControl("GridView1");
        grd.EditIndex = -1;
        grd.DataSource = ds.Tables["Emps"];
        grd.DataBind();  
    }
    protected void GridView1_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {

    }
}