﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Services;

/// <summary>
/// Summary description for WebService
/// </summary>
[WebService(Namespace = "http://tempuri.org/")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
// To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
// [System.Web.Script.Services.ScriptService]
public class WebService : System.Web.Services.WebService {

    public WebService () {

        //Uncomment the following line if using designed components 
        //InitializeComponent(); 
    }

    [WebMethod]
    public string HelloWorld() {
        return "Hello World";
    }

    [WebMethod]
    public int add(int a,int b)
    {
        return a + b;
    }
 
    [WebMethod]
    public MyClass getMyClass()
    {
        return new MyClass();
    }

    [WebMethod]
    public DataSet getDataSet()
    {
        SqlConnection cn = new SqlConnection(@"Data Source=(localdb)\Projects;Initial Catalog=koko;Integrated Security=True;");
        cn.Open();

        SqlCommand cmd = new SqlCommand();
        cmd.Connection = cn;
        cmd.CommandText = "select * from Employees";

        SqlDataAdapter da = new SqlDataAdapter();
        da.SelectCommand = cmd;

        DataSet ds = new DataSet();
        da.Fill(ds, "Emps");

       // Session["ds"] = ds;

        return ds;
    }

    [WebMethod]
    public void UpdateDb(DataSet ds)
   {
           SqlConnection cn = new SqlConnection(@"Data Source=(localdb)\Projects;Initial Catalog=koko;Integrated Security=True;");
           cn.Open();
           SqlCommand cmdUpdate = new SqlCommand();
           cmdUpdate.Connection = cn;

           cmdUpdate.CommandText = "update Employees set EmpName=@EmpName,Basic=@Basic,DeptNo=@DeptNo where EmpNo=@EmpNo";
           cmdUpdate.Parameters.Add(new SqlParameter { ParameterName = "@EmpName", SourceColumn = "EmpName", SourceVersion = DataRowVersion.Current });
           cmdUpdate.Parameters.Add(new SqlParameter { ParameterName = "@Basic", SourceColumn = "Basic", SourceVersion = DataRowVersion.Current });
           cmdUpdate.Parameters.Add(new SqlParameter { ParameterName = "@DeptNo", SourceColumn = "DeptNo", SourceVersion = DataRowVersion.Current });
           cmdUpdate.Parameters.Add(new SqlParameter { ParameterName = "@EmpNo", SourceColumn = "EmpNo", SourceVersion = DataRowVersion.Original});

           SqlDataAdapter da = new SqlDataAdapter();
           da.UpdateCommand = cmdUpdate;
           da.Update(ds, "Emps");

         
    }
    [WebMethod]
    public void DeleteDb(DataSet ds)
    {
        SqlConnection cn = new SqlConnection(@"Data Source=(localdb)\Projects;Initial Catalog=koko;Integrated Security=True;");
        cn.Open();

        SqlCommand cmdDelete = new SqlCommand();
        cmdDelete.Connection = cn;
        cmdDelete.CommandText = "delete from Employees where EmpNo=@EmpNo";

        cmdDelete.Parameters.Add(new SqlParameter {ParameterName="@EmpNo",SourceColumn="EmpNo",SourceVersion=DataRowVersion.Original});

        SqlDataAdapter da = new SqlDataAdapter();
        da.DeleteCommand = cmdDelete;
        da.Update(ds,"Emps");
    }

}

public class MyClass
{
    private int a;
    public int A
    {
        get { return a; }
        set { a = value; }
    }

    private string str;

    public string Str
    {
        get { return str; }
        set { str = value; }
    }
}
