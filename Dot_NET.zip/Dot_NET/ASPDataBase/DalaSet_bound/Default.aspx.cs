﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if(!IsPostBack)
        {
            SqlConnection cn = new SqlConnection(@"Data Source=(localdb)\Projects;Initial Catalog=koko;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False");
            cn.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = cn;
            SqlDataAdapter da = new SqlDataAdapter();
            da.SelectCommand = cmd;

            DataSet ds = new DataSet();
            cmd.CommandText = "Select * from UserMaster"; 
            da.Fill(ds,"UsrM");
            cmd.CommandText = "Select * from CityMaster";
            da.Fill(ds, "City");

            cmd.CommandText = "Select * from PaymentModeMaster";
            da.Fill(ds, "Payment");
            
            GridView1.DataSource=ds.Tables["UsrM"];
            GridView1.DataBind();
            Session["ds"] = ds;

        }
    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void GridView1_RowEditing(object sender, GridViewEditEventArgs e)
    {
        DataSet ds=(DataSet)Session["ds"];
        GridView1.EditIndex = e.NewEditIndex;
        GridView1.DataSource=ds.Tables["UsrM"];
        GridView1.DataBind();

    }
    protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        DataSet ds=(DataSet)Session["ds"];
        String name=GridView1.Rows[e.RowIndex].Cells[3].Text;

        foreach(DataRow drow in ds.Tables["UsrM"].Rows)
        {
            if(drow.RowState!=DataRowState.Deleted)
            {
                if(drow["UserName"].ToString()==name)
                {
                    drow.Delete();
                }
            }

            GridView1.DataSource = ds.Tables["UsrM"];
            GridView1.DataBind();
        }
    }


    protected void GridView1_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        DataSet ds= (DataSet)Session["ds"];
        GridView1.EditIndex = -1;
        GridView1.DataSource = ds.Tables["UsrM"];
        GridView1.DataBind();
    }
    protected void GridView1_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        DataSet ds = (DataSet)Session["ds"];
        TextBox txtuname = (TextBox)GridView1.Rows[e.RowIndex].Cells[3].Controls[0];
        TextBox txtupass = (TextBox)GridView1.Rows[e.RowIndex].Cells[4].Controls[0];
        TextBox txteml=(TextBox)GridView1.Rows[e.RowIndex].Cells[5].Controls[0];
        TextBox txtaddre=(TextBox)GridView1.Rows[e.RowIndex].Cells[6].Controls[0];
        TextBox txtctid = (TextBox)GridView1.Rows[e.RowIndex].Cells[7].Controls[0];
        TextBox txtpyid = (TextBox)GridView1.Rows[e.RowIndex].Cells[8].Controls[0];
        TextBox txtgnd = (TextBox)GridView1.Rows[e.RowIndex].Cells[9].Controls[0];


        foreach (DataRow drow in ds.Tables["UsrM"].Rows)
        {
            if (drow.RowState != DataRowState.Deleted)
            {
                if (drow["UserName"].ToString() == txtuname.Text)
                {
                    drow["UserName"] = txtuname.Text;
                    drow["UserPass"] = txtupass.Text;
                    drow["EmailId"] = txteml.Text;
                    drow["Address"] = txtaddre.Text;
                    drow["CityId"] = txtctid.Text;
                    drow["PaymentModeId"] = txtpyid.Text;
                    drow["Gender"] = txtgnd.Text;

                    break;
                }
            }
 
        }

        GridView1.EditIndex = -1;
        GridView1.DataSource = ds.Tables["UsrM"];
        GridView1.DataBind();

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        DataSet ds =(DataSet)Session["ds"];

            SqlConnection cn = new SqlConnection(@"Data Source=(localdb)\Projects;Initial Catalog=koko;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False");
            cn.Open(); 
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = cn;
            //DataSet ds = new DataSet();
            cmd.CommandText = "update  UserMaster set UserPass=@UserPass,EmailId=@EmailId,Address=@Address,CityId=@CityId,PaymentModeId=@PAymentModeId,Gender=@Gender where UserName=@UserName";

            cmd.Parameters.Add(new SqlParameter { ParameterName = "@UserPass", SourceColumn = "UserPass", SourceVersion = DataRowVersion.Current });
            cmd.Parameters.Add(new SqlParameter { ParameterName = "@EmailId", SourceColumn = "EmailId", SourceVersion = DataRowVersion.Current });
            cmd.Parameters.Add(new SqlParameter { ParameterName = "@Address", SourceColumn = "Address", SourceVersion = DataRowVersion.Current });
            cmd.Parameters.Add(new SqlParameter { ParameterName = "@CityId", SourceColumn = "CityId", SourceVersion = DataRowVersion.Current });
            cmd.Parameters.Add(new SqlParameter { ParameterName = "@PaymentModeId", SourceColumn = "PaymentModeId", SourceVersion = DataRowVersion.Current });
            cmd.Parameters.Add(new SqlParameter { ParameterName = "@Gender", SourceColumn = "Gender", SourceVersion = DataRowVersion.Current });
            cmd.Parameters.Add(new SqlParameter { ParameterName = "@UserName", SourceColumn = "UserName", SourceVersion = DataRowVersion.Original });

            SqlDataAdapter da = new SqlDataAdapter();
            da.UpdateCommand = cmd;
            da.Update(ds,"UsrM");
      
    }
}