﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Login : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        HttpCookie obj2 = Request.Cookies["coockie"];
        if(!IsPostBack)
        {
            if (obj2 != null)
            {
                Response.Redirect("Home.aspx");
            }
        }   
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        SqlConnection cn = new SqlConnection();
        cn.ConnectionString = @"Data Source=(localdb)\Projects;Initial Catalog=koko;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False";
        cn.Open();
        SqlCommand cmdInsert = new SqlCommand();
        cmdInsert.Connection = cn;

        cmdInsert.CommandText = "Login";
        cmdInsert.CommandType = CommandType.StoredProcedure;

        cmdInsert.Parameters.AddWithValue("@UserName",Username.Text);
        cmdInsert.Parameters.AddWithValue("@UserPass",password.Text);

        int i=Convert.ToInt32(cmdInsert.ExecuteScalar().ToString());

        if(i==1)
        {
                if (checkbox.Checked)
                {
                        HttpCookie obj = new HttpCookie("coockie");
                        obj.Values["Username"] = Username.Text;
                        obj.Values["password"] = password.Text;
                        obj.Expires = DateTime.Now.AddDays(1);
                        Response.Cookies.Add(obj);
                        Response.Redirect("Home.aspx");
                }
       }
        
        else
        {
            Response.Write("Error occure");
            Response.Redirect("Login.aspx");
        }    
        }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        Response.Redirect("Register.aspx");
    }
    protected void password_TextChanged(object sender, EventArgs e)
    {

    }
}

  