﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Register : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        SqlConnection cn = new SqlConnection();
        cn.ConnectionString = @"Data Source=(localdb)\Projects;Initial Catalog=koko;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False";
        cn.Open();
        SqlCommand cmdInsert = new SqlCommand();
        cmdInsert.Connection = cn;
        cmdInsert.CommandText = "details";
        cmdInsert.CommandType = System.Data.CommandType.StoredProcedure;
        SqlDataReader dr = cmdInsert.ExecuteReader();
        
        while(dr.Read())
        {
            //DropDownList1.Items.Add(dr["Name"].ToString());

            CheckBoxList1.DataSource = dr;
            CheckBoxList1.DataTextField = "UserName";
            CheckBoxList1.DataTextField = "HobbyId";
            CheckBoxList1.DataBind();
            dr.NextResult();

            DropDownList1.DataSource = dr;

            DropDownList1.DataTextField = "CityName";
            DropDownList1.DataValueField = "CityId";
            DropDownList1.DataBind();
          
            dr.NextResult();

            RadioButtonList1.DataSource = dr;
            RadioButtonList1.DataTextField = "PaymentModeName";
            RadioButtonList1.DataValueField = "PaymentModeId";
            RadioButtonList1.DataBind();

           

           
        }
        dr.Close();
        cn.Close();

    }
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void Button2_Click(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        SqlConnection cn = new SqlConnection();
        cn.ConnectionString = @"Data Source=(localdb)\Projects;Initial Catalog=koko;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False";
        cn.Open();
        SqlCommand cmdInsert = new SqlCommand();
        cmdInsert.Connection = cn;

        cmdInsert.CommandText ="InsertUserMaster";
        cmdInsert.CommandType = CommandType.StoredProcedure;

        cmdInsert.Parameters.AddWithValue("@UserName",TextBox1.Text);
        cmdInsert.Parameters.AddWithValue("@UserPass", TextBox2.Text);
        cmdInsert.Parameters.AddWithValue("@EmailId", TextBox3.Text);
         cmdInsert.Parameters.AddWithValue("@Address",TextArea1.InnerText);

       
    }
}