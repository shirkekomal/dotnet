﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Login : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        HttpCookie obj2 = Request.Cookies["coockie"];
        if(!IsPostBack)
        {
            if (obj2 != null)
            {
               
                Response.Redirect("Home.aspx");
            }
        }
          
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        

        if ((Username.Text == ("komal")) && (password.Text == ("komal") && checkbox.Checked))
        {
        
                HttpCookie obj = new HttpCookie("coockie");
                obj.Values["Username"] = Username.Text;
                obj.Values["password"] = password.Text;
                obj.Expires = DateTime.Now.AddDays(1);
                Response.Cookies.Add(obj);
                Response.Redirect("Home.aspx");
        
        }
        else if ((Username.Text == ("komal")) && (password.Text == ("komal") && !checkbox.Checked))
        {
            Session["koko"] = Username.Text;
            Response.Redirect("Home.aspx");
        }else
        {
            Response.Write("Error occure");
            Response.Redirect("Login.aspx");
        }
           
        }
    }
