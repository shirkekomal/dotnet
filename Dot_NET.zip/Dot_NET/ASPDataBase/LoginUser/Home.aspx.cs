﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Home : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        
        HttpCookie obj = Request.Cookies["coockie"];
     
        if(obj!=null)
        {
            Label1.Text = "Welcome-->> "+obj.Values["Username"];
        }else if( Session["koko"] !=null)
        {
            Label1.Text = "Welcome-->> " + Session["koko"].ToString();
        }
        else
        {
            Response.Redirect("Login.aspx");
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        HttpCookie obj = Request.Cookies["coockie"];
        if (obj != null)
        {
            obj.Expires = DateTime.Now.AddDays(-1);
            Response.Cookies.Add(obj);
        }

         Session.Abandon();
         Response.Redirect("Login.aspx");
    }
}