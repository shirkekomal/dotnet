﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            SqlConnection cn = new SqlConnection(@"Data Source=(localdb)\Projects;Initial Catalog=koko;Integrated Security=True;");
            cn.Open();

            SqlCommand cmd=new SqlCommand();
            cmd.Connection=cn;
            cmd.CommandText="select * from UserMaster";

            SqlDataAdapter da=new SqlDataAdapter();
            da.SelectCommand=cmd;

            DataSet ds=new DataSet();
            da.Fill(ds,"Users");

            cmd.CommandText = "select * from CityMaster";
            da.Fill(ds, "Citys");

            cmd.CommandText = "select * from PaymentModeMaster";
            da.Fill(ds, "Payments");


            Session["ds"]=ds;

            //ds.Tables["Users"].PrimaryKey
            //DataColumn[] arrcols=new DataColumn[1];
            //arrcols[0] = ds.Tables["Users"].Columns["UserName"];
            //ds.Tables["Users"].PrimaryKey = arrcols;

            GridView1.DataSource=ds.Tables["Users"];
            GridView1.DataBind();    
        }

    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {

        DataSet ds=(DataSet)Session["ds"];

        Label uname = (Label)GridView1.Rows[e.RowIndex].FindControl("Label1");

        foreach(DataRow drow in ds.Tables["Users"].Rows)
        {
            if(drow.RowState!=DataRowState.Deleted)
            {
                if(drow["UserName"].ToString()==uname.Text)
                {
                    drow.Delete();
                    break;
                }
            }
        }

        GridView1.DataSource=ds.Tables["Users"];
        GridView1.DataBind();

    }
    protected void GridView1_RowEditing(object sender, GridViewEditEventArgs e)
    {
        DataSet ds = (DataSet)Session["ds"];
        GridView1.EditIndex = e.NewEditIndex;
        GridView1.DataSource = ds.Tables["Users"];
        GridView1.DataBind();
    }
    protected void GridView1_SelectedIndexChanged1(object sender, EventArgs e)
    {

    }
    protected void GridView1_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        DataSet ds=(DataSet)Session["ds"];
        GridView1.EditIndex = -1;
        GridView1.DataSource=ds.Tables["Users"];
        GridView1.DataBind();

    }
    protected void GridView1_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        DataSet ds=(DataSet)Session["ds"];

        Label txtName = (Label)GridView1.Rows[e.RowIndex].FindControl("Label8");
        TextBox txtPass = (TextBox)GridView1.Rows[e.RowIndex].FindControl("TextBox2");
        TextBox txtEmail = (TextBox)GridView1.Rows[e.RowIndex].FindControl("TextBox3");
        TextBox txtAdd = (TextBox)GridView1.Rows[e.RowIndex].FindControl("TextBox8");
        DropDownList city = (DropDownList)GridView1.Rows[e.RowIndex].FindControl("DropDownList1");
        RadioButtonList pay = (RadioButtonList)GridView1.Rows[e.RowIndex].FindControl("RadioButtonList1");
        RadioButtonList gen = (RadioButtonList)GridView1.Rows[e.RowIndex].FindControl("RadioButtonList2");

        foreach (DataRow drow in ds.Tables["Users"].Rows)
        {
            if (drow.RowState != DataRowState.Deleted)
            {
                if (drow["UserName"].ToString() == txtName.Text)
                {
                    //drow["UserName"] = txtName.Text;
                    drow["UserPass"] = txtPass.Text;
                    drow["EmailId"] = txtEmail.Text;
                    drow["Address"] = txtAdd.Text;
                    drow["CityId"] = city.SelectedValue;
                    drow["PaymentModeId"] = pay.SelectedValue;
                    drow["Gender"] = gen.SelectedValue;
                    break;
                }
            }
        }
        GridView1.EditIndex = -1;
        GridView1.DataSource = ds.Tables["Users"];
        GridView1.DataBind();

    }

    protected DataTable getPayment()
    {
        DataSet ds = (DataSet)Session["ds"];
        return ds.Tables["Payments"];
    }

    protected DataTable getCity()
    {
        DataSet ds = (DataSet)Session["ds"];
        return ds.Tables["Citys"];
    }
    protected void GridView1_Sorting(object sender, GridViewSortEventArgs e)
    {
        DataSet ds=(DataSet) Session["ds"];
       //DataView dv = new DataView(ds.Tables["Users"]);
       //dv.Sort = e.SortExpression;
       //GridView1.DataSource = dv;
       //GridView1.DataBind();

        ds.Tables["Users"].DefaultView.Sort = e.SortExpression;
        GridView1.DataSource = ds.Tables["Users"];
        GridView1.DataBind();


    }
    protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        DataSet ds = (DataSet)Session["ds"];
        GridView1.PageIndex = e.NewPageIndex;
        GridView1.DataSource = ds.Tables["Users"];
        GridView1.DataBind();

    }
   
    protected void GridView1_RowCreated(object sender, GridViewRowEventArgs e)
    {
         DataSet ds = (DataSet)Session["ds"];

        if (e.Row.RowType == DataControlRowType.Footer)
        {
            DropDownList dt = (DropDownList)e.Row.FindControl("DropDownList2");
            dt.DataSource = ds.Tables["Citys"];
            dt.DataTextField = "CityName";
            dt.DataValueField = "CityId";
            dt.DataBind();

            RadioButtonList paym = (RadioButtonList)e.Row.FindControl("RadioButtonList4");
            paym.DataSource = ds.Tables["Payments"];
            paym.DataTextField = "PaymentModeName";
            paym.DataValueField = "PaymentModeId";
            paym.DataBind();
        }   

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
         DataSet ds = (DataSet)Session["ds"];
        TextBox txtNm = (TextBox)GridView1.FooterRow.FindControl("TextBox9");
        TextBox txtPass = (TextBox)GridView1.FooterRow.FindControl("TextBox10");
        TextBox txtEmail = (TextBox)GridView1.FooterRow.FindControl("TextBox11");
        TextBox txtAddr = (TextBox)GridView1.FooterRow.FindControl("TextBox12");
        DropDownList cty = (DropDownList)GridView1.FooterRow.FindControl("DropDownList2");
        RadioButtonList pymt = (RadioButtonList)GridView1.FooterRow.FindControl("RadioButtonList4");
        RadioButtonList gen = (RadioButtonList)GridView1.FooterRow.FindControl("RadioButtonList5");

        DataRow drow = ds.Tables["Users"].NewRow();

        drow["UserName"] = txtNm.Text;
        drow["UserPass"] = txtPass.Text;
        drow["EmailId"] = txtEmail.Text;
        drow["Address"] = txtAddr.Text;
        drow["CityId"] = cty.SelectedValue;
        drow["PaymentModeId"] = pymt.SelectedValue;
        drow["Gender"] = gen.SelectedValue;

        ds.Tables["Users"].Rows.Add(drow);

        GridView1.DataSource = ds.Tables["Users"];
        GridView1.DataBind();
    }
    protected void Button2_Click(object sender, EventArgs e)
    {

        DataSet ds = (DataSet)Session["ds"];

        SqlConnection cn = new SqlConnection(@"Data Source=(localdb)\Projects;Initial Catalog=koko;Integrated Security=True;");
        cn.Open();

        SqlCommand cmdInsert = new SqlCommand();
        cmdInsert.Connection = cn;
        cmdInsert.CommandText = "insert into UserMaster values(@UserName,@UserPass,@EmailId,@Address,@CityId,@PaymentModeId,@Gender)";

        //SqlParameter p = new SqlParameter();
        //p.ParameterName = "@UserName";
        //p.SourceColumn = "UserName";
        //p.SourceVersion = DataRowVersion.Current;
        //cmdInsert.Parameters.Add(p);

        cmdInsert.Parameters.Add(new SqlParameter { ParameterName = "@UserName", SourceColumn = "UserName", SourceVersion = DataRowVersion.Current });
        cmdInsert.Parameters.Add(new SqlParameter { ParameterName = "@UserPass", SourceColumn = "UserPass", SourceVersion = DataRowVersion.Current });
        cmdInsert.Parameters.Add(new SqlParameter { ParameterName = "@EmailId", SourceColumn = "EmailId", SourceVersion = DataRowVersion.Current });
        cmdInsert.Parameters.Add(new SqlParameter { ParameterName = "@Address", SourceColumn = "Address", SourceVersion = DataRowVersion.Current });
        cmdInsert.Parameters.Add(new SqlParameter { ParameterName = "@CityId", SourceColumn = "CityId", SourceVersion = DataRowVersion.Current });
        cmdInsert.Parameters.Add(new SqlParameter { ParameterName = "@PaymentModeId", SourceColumn = "PaymentModeId", SourceVersion = DataRowVersion.Current });
        cmdInsert.Parameters.Add(new SqlParameter { ParameterName = "@Gender", SourceColumn = "Gender", SourceVersion = DataRowVersion.Current });

        SqlCommand cmdUpdate = new SqlCommand();
        cmdUpdate.Connection = cn;
        cmdUpdate.CommandText = "update UserMaster set UserPass=@UserPass,EmailId=@EmailId,Address=@Address,CityId=@CityId,PaymentModeId=@PaymentModeId,Gender=@Gender where UserName=@UserName";

        cmdUpdate.Parameters.Add(new SqlParameter { ParameterName = "@UserName", SourceColumn = "UserName", SourceVersion = DataRowVersion.Original});
        cmdUpdate.Parameters.Add(new SqlParameter {ParameterName="@UserPass",SourceColumn="UserPass",SourceVersion=DataRowVersion.Current});
        cmdUpdate.Parameters.Add(new SqlParameter { ParameterName = "@EmailId", SourceColumn = "EmailId", SourceVersion = DataRowVersion.Current});
        cmdUpdate.Parameters.Add(new SqlParameter { ParameterName = "@Address", SourceColumn = "Address", SourceVersion = DataRowVersion.Current});
        cmdUpdate.Parameters.Add(new SqlParameter { ParameterName = "@CityId", SourceColumn = "CityId", SourceVersion = DataRowVersion.Current});
        cmdUpdate.Parameters.Add(new SqlParameter { ParameterName = "@PaymentModeId", SourceColumn = "PaymentModeId", SourceVersion = DataRowVersion.Current });
        cmdUpdate.Parameters.Add(new SqlParameter { ParameterName = "@Gender", SourceColumn = "Gender", SourceVersion = DataRowVersion.Current });

        SqlCommand cmdDelete = new SqlCommand();
        cmdDelete.Connection = cn;
        cmdDelete.CommandText = "Delete from UserMaster where UserName=@UserName";

        cmdDelete.Parameters.Add(new SqlParameter {ParameterName="@UserName",SourceColumn="UserName",SourceVersion=DataRowVersion.Original});


        SqlDataAdapter da = new SqlDataAdapter();
        da.InsertCommand = cmdInsert;
        da.UpdateCommand = cmdUpdate;
        da.DeleteCommand = cmdDelete;
        da.Update(ds, "Users");
    }
}