﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class DataList : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            SqlConnection cn = new SqlConnection(@"Data Source=(localdb)\Projects;Initial Catalog=koko;Integrated Security=True;");
            cn.Open();

            SqlCommand cmd = new SqlCommand();
            cmd.Connection = cn;
            cmd.CommandText = "select * from UserMaster";

            SqlDataAdapter da = new SqlDataAdapter();
            da.SelectCommand = cmd;

            DataSet ds = new DataSet();
            da.Fill(ds, "Users");

            cmd.CommandText = "select * from CityMaster";
            da.Fill(ds, "Citys");

            cmd.CommandText = "select * from PaymentModeMaster";
            da.Fill(ds, "Payments");


            Session["ds"] = ds;

            //ds.Tables["Users"].PrimaryKey
            //DataColumn[] arrcols=new DataColumn[1];
            //arrcols[0] = ds.Tables["Users"].Columns["UserName"];
            //ds.Tables["Users"].PrimaryKey = arrcols;

            DataList1.DataSource = ds.Tables["Users"];
            DataList1.DataBind();
        }
    }

    protected void Delete(object source, DataListCommandEventArgs e)
    {
        DataSet ds = (DataSet)Session["ds"];

        Label uname = (Label)e.Item.FindControl("Label12");

        foreach (DataRow drow in ds.Tables["Users"].Rows)
        {
            if (drow.RowState != DataRowState.Deleted)
            {
                if (drow["UserName"].ToString() == uname.Text)
                {
                    drow.Delete();
                    break;
                }
            }
        }

        DataList1.DataSource = ds.Tables["Users"];
        DataList1.DataBind();
    }

    protected void Edit(object source, DataListCommandEventArgs e)
    {
        DataSet ds = (DataSet)Session["ds"];
        DataList1.EditItemIndex = e.Item.ItemIndex;
        DataList1.DataSource = ds.Tables["Users"];
        DataList1.DataBind();

    }

  

    protected void Update(object source, DataListCommandEventArgs e)
    {
        DataSet ds = (DataSet)Session["ds"];

        Label txtName = (Label)e.Item.FindControl("Label27");
        TextBox txtPass = (TextBox)e.Item.FindControl("TextBox2");
        TextBox txtEmail = (TextBox)e.Item.FindControl("TextBox3");
        TextBox txtAdd = (TextBox)e.Item.FindControl("TextBox4");
        DropDownList city = (DropDownList)e.Item.FindControl("DropDownList1");
        RadioButtonList pay = (RadioButtonList)e.Item.FindControl("RadioButtonList1");
        RadioButtonList gen = (RadioButtonList)e.Item.FindControl("RadioButtonList2");

        foreach (DataRow drow in ds.Tables["Users"].Rows)
        {
            if (drow.RowState != DataRowState.Deleted)
            {
                if (drow["UserName"].ToString() == txtName.Text)
                {
                    //drow["UserName"] = txtName.Text;
                    drow["UserPass"] = txtPass.Text;
                    drow["EmailId"] = txtEmail.Text;
                    drow["Address"] = txtAdd.Text;
                    drow["CityId"] = city.SelectedValue;
                    drow["PaymentModeId"] = pay.SelectedValue;
                    drow["Gender"] = gen.SelectedValue;
                    break;
                }
            }
        }
        DataList1.EditItemIndex = -1;
        DataList1.DataSource = ds.Tables["Users"];
        DataList1.DataBind();
    }

    protected void DataList1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }

    protected void RadioButtonList1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }

    protected DataTable getPayment()
    {
        DataSet ds = (DataSet)Session["ds"];
        return ds.Tables["Payments"];
    }

    protected DataTable getCity()
    {
        DataSet ds = (DataSet)Session["ds"];
        return ds.Tables["Citys"];
    }

    protected void Cancel(object source, DataListCommandEventArgs e)
    {
        DataSet ds = (DataSet)Session["ds"];
        DataList1.EditItemIndex = -1;
        DataList1.DataSource = ds.Tables["Users"];
        DataList1.DataBind();
    }

    protected void DataList1_ItemCommand(object source, DataListCommandEventArgs e)
       {
        if(e.Item.ItemType==ListItemType.Footer)
        {
            if(e.CommandName=="Insert")
            {

            }
        }
    }
}