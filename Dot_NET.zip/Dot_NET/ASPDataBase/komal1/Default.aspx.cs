﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
    //    localhost.WebService obj = new localhost.WebService();
    //    DataSet ds = obj.getdataSet();
    //    Session["ds"] = ds;
    //
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        localhost.WebService obj = new localhost.WebService();
        Label1.Text = obj.HelloWorld();
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        localhost.WebService obj = new localhost.WebService();
        int a =Convert.ToInt32(TextBox1.Text);
        int b =Convert.ToInt32(TextBox2.Text);
        Label2.Text =(obj.Add(a,b)).ToString();
    }


    protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        DataSet ds=(DataSet)Session["ds"];
        string empno = GridView1.Rows[e.RowIndex].Cells[3].Text;

        foreach(DataRow drow in ds.Tables["Emp"].Rows)
        {
            if(drow.RowState!=DataRowState.Deleted)
            {
                if(drow["EmpNo"].ToString()==empno)
                {
                    drow.Delete();
                    break;
                }
            }

            GridView1.DataSource = ds.Tables["Emp"];
            GridView1.DataBind();
        }

    }

    protected void Button3_Click(object sender, EventArgs e)
    {
        localhost.WebService obj = new localhost.WebService();
        DataSet ds = obj.getdataSet();
        Session["ds"] = ds;
        GridView1.DataSource = ds.Tables["Emp"];
        GridView1.DataBind();


    }
    protected void GridView1_RowEditing(object sender, GridViewEditEventArgs e)
    {
        DataSet ds = (DataSet)Session["ds"];
        GridView1.EditIndex = e.NewEditIndex;
        GridView1.DataSource=ds.Tables["Emp"];
        GridView1.DataBind();

    }
    protected void GridView1_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        DataSet ds=(DataSet)Session["ds"];
        GridView1.EditIndex = -1;
        GridView1.DataSource = ds.Tables["Emp"];
        GridView1.DataBind();
    }
    protected void GridView1_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
         DataSet ds = (DataSet)Session["ds"];

        TextBox txtNo = (TextBox)GridView1.Rows[e.RowIndex].Cells[3].Controls[0];
        TextBox txtname = (TextBox)GridView1.Rows[e.RowIndex].Cells[4].Controls[0];
        TextBox txtBasic = (TextBox)GridView1.Rows[e.RowIndex].Cells[5].Controls[0];
        TextBox txtDeptno = (TextBox)GridView1.Rows[e.RowIndex].Cells[6].Controls[0];

        foreach (DataRow drow in ds.Tables["Emp"].Rows)
        {
            if(drow.RowState!=DataRowState.Deleted)
            {
                if(drow["EmpNo"].ToString()==txtNo.Text)
                {
                    drow["EmpName"] = txtname.Text;
                    drow["Basic"] = txtBasic.Text;
                    drow["DeptNo"] = txtDeptno.Text;
                    break;
                }
            } 
        }
        GridView1.EditIndex = -1;
        GridView1.DataSource = ds.Tables["Emp"];
        GridView1.DataBind();
    }

    protected void Button4_Click(object sender, EventArgs e)
    {
        localhost.WebService obj = new localhost.WebService();
        DataSet ds = (DataSet)Session["ds"];
        obj.updateDb(ds);
       
    }
}