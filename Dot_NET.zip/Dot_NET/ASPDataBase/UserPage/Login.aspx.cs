﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Login : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        HttpCookie obj2 = Request.Cookies["coockie"];
        if (!IsPostBack)
        {
            if (obj2 != null)
            {
                Response.Redirect("Home.aspx");
            }
        } 
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        SqlConnection cn = new SqlConnection(@"Data Source=(localdb)\Projects;Initial Catalog=koko;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False");
        cn.Open();
        SqlCommand cmd = new SqlCommand();
        cmd.Connection = cn;
        cmd.CommandText = "Select count(*) from UserMaster where UserName=@name";
        cmd.Parameters.AddWithValue("@name",TextBox1.Text);
       int o=Convert.ToInt32( cmd.ExecuteScalar().ToString());

        if(o>0)
        {
                    if(CheckBox1.Checked)
                    {
                        HttpCookie cookie = new HttpCookie("coockie");
                        cookie.Values["UserName"] = TextBox1.Text;
                        cookie.Values["UserPass"] = TextBox2.Text;

                        cookie.Expires = DateTime.Now.AddDays(1);
                        Response.Cookies.Add(cookie);
                        Response.Redirect("Home.aspx");

                    }
                    else
                    {
                        Session["kk"] = TextBox1.Text;
                            //Response.Redirect("Home.aspx");
                    }
                    Response.Redirect("Home.aspx");

            }


            else
            {
                Console.WriteLine("Enter Valid Details");
                Response.Redirect("Login.aspx");
            }
        
    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        Response.Redirect("Register.aspx");
    }
}