﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Template : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            SqlConnection cn = new SqlConnection(@"Data Source=(localdb)\Projects;Initial Catalog=koko;Integrated Security=True;");
            cn.Open();

            SqlCommand cmd = new SqlCommand();
            cmd.Connection = cn;
            cmd.CommandText = "select * from Departments";

            SqlDataAdapter da = new SqlDataAdapter();
            da.SelectCommand = cmd;

            DataSet ds = new DataSet();
            da.Fill(ds, "Deps");

            cmd.CommandText = "select * from Employees";
            da.Fill(ds, "Emps");

            Session["ds"] = ds;

            GridView1.DataSource = ds.Tables["Emps"];
            GridView1.DataBind();
        }
    }
    protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        DataSet ds = (DataSet)Session["ds"];
        String empno = GridView1.Rows[e.RowIndex].Cells[3].Text;

        foreach (DataRow drow in ds.Tables["Emps"].Rows)
        {

            if (drow.RowState != DataRowState.Deleted)
            {
                if (drow["EmpNo"].ToString() == empno)
                {
                    drow.Delete();
                    break;
                }
            }
        }
        GridView1.EditIndex = -1;
        GridView1.DataSource = ds.Tables["Emps"];
        GridView1.DataBind();
    }
    protected void GridView1_RowEditing(object sender, GridViewEditEventArgs e)
    {
        DataSet ds = (DataSet)Session["ds"];
        GridView1.EditIndex = e.NewEditIndex;
        GridView1.DataSource = ds.Tables["Emps"];
        GridView1.DataBind();

    }
    protected void GridView1_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        DataSet ds = (DataSet)Session["ds"];
        GridView1.EditIndex = -1;
        GridView1.DataSource = ds.Tables["Emps"];
        GridView1.DataBind();
    }

    protected void GridView1_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        DataSet ds = (DataSet)Session["ds"];
        TextBox txtName = (TextBox)GridView1.Rows[e.RowIndex].Cells[3].FindControl("TextBox1");
         TextBox txtNo = (TextBox)GridView1.Rows[e.RowIndex].Cells[4].FindControl("TextBox4");
         TextBox txtBasic = (TextBox)GridView1.Rows[e.RowIndex].Cells[5].FindControl("TextBox3");
         DropDownList txtDeptNo = (DropDownList)GridView1.Rows[e.RowIndex].Cells[6].FindControl("DropDownList1");

        foreach (DataRow drow in ds.Tables["Emps"].Rows)
        {
            if (drow.RowState != DataRowState.Deleted)
            {
                if (drow["EmpNo"].ToString() == txtNo.Text)
                {
                    drow["EmpName"] = txtName.Text;
                    drow["Basic"] = txtBasic.Text;
                    drow["DeptNo"] = txtDeptNo.SelectedValue;
                    break;
                }
            }
        }
        GridView1.EditIndex=-1;
        GridView1.DataSource = ds.Tables["Emps"];
        GridView1.DataBind();

    }
    protected void GridView1_SelectedIndexChanged2(object sender, EventArgs e)
    {

    }

    protected DataTable getDept()
    {
        DataSet ds = (DataSet)Session["ds"];
        return ds.Tables["Deps"];
    }
}