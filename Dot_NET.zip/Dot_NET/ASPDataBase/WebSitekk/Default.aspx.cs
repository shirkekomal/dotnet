﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        localhost12.WebService obj = new localhost12.WebService();
        Label1.Text= obj.HelloWorld();
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        localhost12.WebService obj = new localhost12.WebService();
        int a = Convert.ToInt32(TextBox5.Text);
        int b = Convert.ToInt32(TextBox6.Text);
        Label2.Text = obj.add(a,b).ToString();
    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        localhost12.WebService obj = new localhost12.WebService();
        localhost12.MyClass mcs = obj.getMyClass();
        mcs.A = 10;
        mcs.Str = "komal";
        Label3.Text = mcs.A + " " + mcs.Str;
    }
    protected void Button4_Click(object sender, EventArgs e)
    {
        localhost12.WebService obj = new localhost12.WebService();
        DataSet ds = obj.getDataSet();
        Session["ds"] = ds;
        GridView1.DataSource = ds.Tables["Emps"];
        GridView1.DataBind();

    }
   

    protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        DataSet ds = (DataSet)Session["ds"];

        String empNo=GridView1.Rows[e.RowIndex].Cells[2].Text;

        foreach (DataRow drow in ds.Tables["Emps"].Rows)
        {
            if(drow.RowState!=DataRowState.Deleted)
            {
                if(drow["EmpNo"].ToString()== empNo)
                {
                    drow.Delete();
                    break;
                }
            }
        }
        GridView1.DataSource = ds.Tables["Emps"];
        GridView1.DataBind();
        
    }

    protected void GridView1_RowEditing(object sender, GridViewEditEventArgs e)
    {
        DataSet ds=(DataSet)Session["ds"];
        GridView1.EditIndex = e.NewEditIndex;
        GridView1.DataSource = ds.Tables["Emps"];
        GridView1.DataBind();
    }

    protected void GridView1_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        DataSet ds=(DataSet)Session["ds"];
        GridView1.EditIndex = -1;
        GridView1.DataSource=ds.Tables["Emps"];
        GridView1.DataBind();
    }
    protected void GridView1_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        DataSet ds = (DataSet)Session["ds"];

        TextBox txtNo = (TextBox)GridView1.Rows[e.RowIndex].Cells[2].Controls[0];
        TextBox txtname = (TextBox)GridView1.Rows[e.RowIndex].Cells[3].Controls[0];
        TextBox txtBasic = (TextBox)GridView1.Rows[e.RowIndex].Cells[4].Controls[0];
        TextBox txtDeptno = (TextBox)GridView1.Rows[e.RowIndex].Cells[5].Controls[0];

        foreach (DataRow drow in ds.Tables["Emps"].Rows)
        {
            if(drow.RowState!=DataRowState.Deleted)
            {
                if(drow["EmpNo"].ToString()==txtNo.Text)
                {
                    drow["EmpName"] = txtname.Text;
                    drow["Basic"] = txtBasic.Text;
                    drow["DeptNo"] = txtDeptno.Text;
                    break;
                }
            } 
        }
        GridView1.EditIndex = -1;
        GridView1.DataSource = ds.Tables["Emps"];
        GridView1.DataBind();
    }
    protected void Button5_Click(object sender, EventArgs e)
    {
        DataSet ds = (DataSet)Session["ds"];
        localhost12.WebService obj = new localhost12.WebService();
        obj.UpdateDb(ds);
    }

    protected void Button6_Click(object sender, EventArgs e)
    {
        DataSet ds=(DataSet)Session["ds"];
        localhost12.WebService obj = new localhost12.WebService();
        obj.DeleteDb(ds);
    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
}