﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
   

    protected void Page_Load(object sender, EventArgs e)
    {
        
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        localhost.WebService obj = new localhost.WebService();
        
        Label1.Text = obj.HelloWorld();
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        localhost.WebService obj = new localhost.WebService();
        int a =Convert.ToInt32(TextBox1.Text);
        int b = Convert.ToInt32(TextBox2.Text);
         int c= obj.Add(a, b);


    }
   

    protected void Button3_Click(object sender, EventArgs e)
    {
         localhost.WebService obj1 = new localhost.WebService();
         DataSet ds = new DataSet();
         ds = obj1.GetDataSets();
        GridView1.DataSource = ds.Tables["Emps"];
        GridView1.DataBind();
    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
}