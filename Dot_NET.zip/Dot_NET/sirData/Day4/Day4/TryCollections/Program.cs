﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TryCollections
{
    class Program
    {
        static void Main1()
        {
            ArrayList o = new ArrayList();
            o.Add(10);
            o.Add("aaa");
            o.Add("bbb");
            o.Add("ccc");
            o.RemoveAt(0);
            o.Remove("aaa");
            for (int i = 0; i < o.Count; i++)
                Console.WriteLine(o[i]);
            foreach (object obj in o)
                Console.WriteLine(obj);
            foreach (var item in o)
                Console.WriteLine(item);
            Console.ReadLine();
        }
        static void Main2()
        {
            //Hashtable obj = new Hashtable();
            SortedList obj = new SortedList();
            obj.Add(1, "a");
            //obj.Add(1, "a");
            obj[2] = "b";
            obj[2] = "c";
            obj[3] = "c";
            obj.Remove(3);
            obj[4] = "d";
            foreach (DictionaryEntry objEntry in obj)
            {
                Console.WriteLine(objEntry.Key);
                Console.WriteLine(objEntry.Value);
            }
            

            Console.ReadLine();
        }
        static void Main3()
        {
            Stack s = new Stack();
            s.Push(10);
            s.Push(20);
            s.Push(30);

            Console.WriteLine(s.Peek());
            Console.WriteLine(s.Pop());
            Console.WriteLine(s.Pop());
            Console.WriteLine(s.Pop());

        }
        static void Main4()
        {
            Queue q = new Queue();
            q.Enqueue(10);
            q.Enqueue(20);
            q.Enqueue(30);

            Console.WriteLine(q.Peek());
            Console.WriteLine(q.Dequeue());
            Console.WriteLine(q.Dequeue());
            Console.WriteLine(q.Dequeue());

        }
        static void Main5()
        {
            List<int> objList = new List<int>();
            objList.Add(10);
            List<string> objList2 = new List<string>();
            objList2.Add("aa");

            objList.Remove(10);
            foreach (int i in objList)
            {
                Console.WriteLine(i);
            }
            Console.ReadLine();
        }
        static void Main6()
        {
            SortedList<int, string> objList = new SortedList<int, string>();
            objList.Add(10, "aaa");
            objList[20] = "bbb";
            objList.Remove(10);
            foreach (KeyValuePair<int, string> kvp in objList)
            {
                Console.WriteLine(kvp.Value);
            }

            Stack<int> objStack = new Stack<int>();
            objStack.Push(10);

            Console.ReadLine();
        }

        static void Main()
        {
            List<Employee> objList = new List<Employee>();
            Employees objList3 = new Employees();
            objList3.Add(new Employee { EmpNo = 1, Name = "aaa" });
            
            
            objList.Add(new Employee { EmpNo = 1, Name = "aaa" });
            objList.Add(new Employee { EmpNo = 2, Name = "bbb" });
            objList.Add(new Employee { EmpNo = 3, Name = "ccc" });

            SortedList<int, Employee> objList2 = new SortedList<int, Employee>();
            objList2.Add(1, new Employee { EmpNo = 1, Name = "aaa" });
            objList2.Add(2, new Employee { EmpNo = 2, Name = "bbb" });
            objList2.Add(3, new Employee { EmpNo = 3, Name = "vvv" });

            Console.ReadLine();
        }

    }

    public class Employees : List<Employee>  { }


    public class Employee
    {
        private string name;

        public string Name
        {
            get { return name; }
            set { name = value; }
        }
        private int empNo;

        public int EmpNo
        {
            get { return empNo; }
            set { empNo = value; }
        }
    }

}
