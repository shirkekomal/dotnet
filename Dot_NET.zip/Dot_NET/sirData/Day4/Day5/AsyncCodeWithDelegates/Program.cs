﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace AsyncCodeWithDelegates1
{
    class Program
    {
        static void Main1()
        {
            Action objDel = Display;
            Console.WriteLine("Before ...");
            //BeginInvoke calls Display method on a new Thread
            objDel.BeginInvoke(null, null);
            Console.WriteLine("After ...");

            Console.ReadLine();
        }
        static void Display()
        {
            Thread.Sleep(3000);
            Console.WriteLine("Display");
        }
    }
}
namespace AsyncCodeWithDelegates2
{
    class Program
    {
        static void Main2()
        {
            Action<string> objDel = Display;
            Console.WriteLine("Before ...");
            //BeginInvoke calls Display method on a new Thread
            //calling a method that has parameters
            objDel.BeginInvoke("hello", null, null);
            Console.WriteLine("After ...");

            Console.ReadLine();
        }
        static void Display(string s)
        {
            Thread.Sleep(3000);
            Console.WriteLine("Display...." + s);
        }
    }
}
namespace AsyncCodeWithDelegates3
{
    class Program
    {
        static void Main1()
        {
            Func<string,string> objDel = Display;
            Console.WriteLine("Before ...");
            //BeginInvoke calls Display method on a new Thread
            //calling a method that has a return value

            //objDel.BeginInvoke("hello", new AsyncCallback(CallBackFunction), null);

            //last parameter contains objDel. objDel is required in the callback function
            //   to get the return value from Display method
            
            objDel.BeginInvoke("hello", CallBackFunction, objDel);

            Console.WriteLine("After ...");
            Console.ReadLine();
        }

        static void CallBackFunction(IAsyncResult ar)
        {
            //call back function will be called when Display is over
            //write code here to get the return value from the Display function
            Console.WriteLine("callback func");

            //ar.AsyncState contains the last parameter passed in BeginInvoke
            Func<string, string> objDel = (Func<string, string>)ar.AsyncState;

            //return value is got by calling objDel.EndInvoke
            string s = objDel.EndInvoke(ar);
            Console.WriteLine("result = " + s);
        }

        static string Display(string s)
        {
            Thread.Sleep(3000);
            Console.WriteLine("Display...." + s);
            return s.ToUpper();
        }
    }
}
namespace AsyncCodeWithDelegates4
{
    class Program
    {
        static void Main()
        {
            Func<string, string> objDel = Display;
            Console.WriteLine("Before ...");

            //using an anonymous method to access objDel declared in the calling code
            objDel.BeginInvoke("hello",  delegate(IAsyncResult ar)
                    {
                        //call back function will be called when Display is over
                        //write code here to get the return value from the Display function
                        Console.WriteLine("callback func");
                        //return value is got by calling objDel.EndInvoke
                        string s = objDel.EndInvoke(ar);
                        Console.WriteLine("result = " + s);
                    }  
                    , null);

            Console.WriteLine("After ...");
            Console.ReadLine();
        }

        static string Display(string s)
        {
            Thread.Sleep(3000);
            Console.WriteLine("Display...." + s);
            return s.ToUpper();
        }
    }
}


