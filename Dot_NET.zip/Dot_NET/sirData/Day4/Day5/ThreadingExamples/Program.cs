﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace ThreadingExamples1
{
    class Program
    {
        const int MAX = 50000;
        static void Main1()
        {
            Thread t1 = new Thread(Func1);
            Thread t2 = new Thread(Func2);
            t1.Priority = ThreadPriority.Highest;
            t2.Priority = ThreadPriority.Lowest;
            //t1.Abort();
            //if(t1.ThreadState == ThreadState.)
            //t1.IsBackground = false;

            t1.Start();
            t2.Start();
            for (int i = 0; i < 1; i++)
            {
                Console.WriteLine("Main Thread " + i.ToString());
            }
            //t1.Join();
            //t2.Join();
            Console.ReadLine();
        }
        static void Main2()
        {
            Thread t = new Thread(Func3);
            Console.WriteLine("before");

            t.Start(1000);

            Console.WriteLine("after");

            Console.ReadLine();
        }

        static void Func3(object o)
        {
            Thread.Sleep(3000);
            Console.WriteLine(o);
        }

        static void Func1()
        {
            for (int i = 0; i < MAX; i++)
            {
                Console.WriteLine("First Thread " + i.ToString());
            }
        }
        static void Func2()
        {
            for (int i = 0; i < MAX; i++)
            {
                Console.WriteLine("Second Thread " + i.ToString());
            }
        }
    }
}

namespace ThreadingExamples2
{
    class Program
    {
        const int MAX = 50000;
        static void Main()
        {
            Console.WriteLine("before");
            ThreadPool.QueueUserWorkItem(Func1);
            ThreadPool.QueueUserWorkItem(Func3,1234);
            Console.WriteLine("after");

            Console.ReadLine();
        }

        static void Func3(object o)
        {
            Thread.Sleep(3000);
            Console.WriteLine(o);
        }

        static void Func1(object o)
        {
            Thread.Sleep(4000);
            Console.WriteLine("Func1 ");
        }
        static void Func2()
        {
            for (int i = 0; i < MAX; i++)
            {
                Console.WriteLine("Second Thread " + i.ToString());
            }
        }
    }
}
