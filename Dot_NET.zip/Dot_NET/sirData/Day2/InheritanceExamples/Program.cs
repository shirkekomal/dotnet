﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasicInheritance
{
    public class BaseClass
    {
        public int i;
    }
    public class DerivedClass : BaseClass
    {
        public int j;
    }
    class Program
    {
        static void Main1()
        {
            DerivedClass o = new DerivedClass();
            //o.
        }
    }
}

namespace TestAccessSpecifiers
{
    public class BaseClass
    {
        public int PUBLIC; //available everywhere
        private int PRIVATE;// only in same class
        protected int PROTECTED;// same class, derived class
        internal int INTERNAL;//same class, same assembly
        protected internal int PROTECTED_INTERNAL;//same class, derived class, same assembly
    }
    public class DerivedClass : AccessSpecifiers.BaseClass
    //public class DerivedClass : BaseClass
    {
        void DoSomething()
        {
            //this.
        }
    }
    class Program
    {
        static void Main1()
        {
            DerivedClass o = new DerivedClass();
            //o
        }
    }
}


namespace Constructors
{
    public class BaseClass
    {
        public int i;
        public BaseClass()
        {
            i = 0;
            Console.WriteLine("base class void cons");
        }
        public BaseClass(int i)
        {
            this.i = i;
            Console.WriteLine("base class int cons");
        }
    }
    public class DerivedClass : BaseClass
    {
        public int j;
        public DerivedClass()
        {
            j = 0;
            Console.WriteLine("derived class void cons");
        }
        public DerivedClass(int i, int j) : base(i)
        {
            this.j = j;
            Console.WriteLine("derived class int cons");
        }
    }
    class Program
    {
        static void Main2()
        {
            //DerivedClass o = new DerivedClass();
            DerivedClass o = new DerivedClass(10, 20);
            //o.
            Console.ReadLine();
        }
    }
}

namespace SameNameFunctions
{
    public class BaseClass
    {
        public void Display1()
        {
            Console.WriteLine("Display1 from base");
        }
        public void Display2()
        {
            Console.WriteLine("Display2 from base");
        }
        public virtual void Display3()
        {
            Console.WriteLine("Display3 from base");
        }
    }
    public class DerivedClass : BaseClass
    {
        //overloading a base class function
        public void Display1(string s)
        {
            Console.WriteLine("Display1 from derived");
        }
        //Hiding a base class function
        public new void Display2()
        {
            Console.WriteLine("Display2 from derived");
        }
        //overriding a base class function
        public override void Display3()
        {
            Console.WriteLine("Display3 from derived");
        }
    }
    public class SubDerivedClass : DerivedClass
    {
        //sealed methods cannot be overriden
        public sealed override void Display3()
        {
            Console.WriteLine("Display3 from subderived");
        }
    }
    public class SubSubDerivedClass : SubDerivedClass
    {
        public void Display3()
        {
            Console.WriteLine("Display3 from subsubderived");
        }
    }
    
    class Program
    {
        static void Main1()
        {
            DerivedClass o = new DerivedClass();

            o.Display1();
            o.Display1("a");

            o.Display2();
            //o.Display1();
            //o.Display1("aa");

            //o.Display2();
            o.Display3();

            Console.ReadLine();
        }
        static void Main2()
        {
            BaseClass o;
            o = new BaseClass();
            //o.Display2();
            o.Display3();

            Console.WriteLine();

            o = new DerivedClass();
            //o.Display2();
            o.Display3();

            Console.WriteLine();

            o = new SubDerivedClass();
            //o.Display2();
            o.Display3();

            o = new SubSubDerivedClass();
            //o.Display2();
            o.Display3();




            /*
            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine();
            o = new BaseClass();
            BaseClass o2 = new DerivedClass();
            BaseClass o3 = new SubDerivedClass();

            CallDisplay3(o);
            CallDisplay3(o2);
            CallDisplay3(o3);


            */
            Console.ReadLine();
        }
      
        static void CallDisplay3(BaseClass o)
        {
            o.Display3();
        }
    }
}

namespace AbstractAndSealedClasses
{
    public abstract class BaseClass
    {
        public int i;
        public abstract void Display(); //abstract or pure virtual function
    }
    public class Derived : BaseClass
    {
        public override void Display()
        {
            Console.WriteLine("disp");
        }
    }
    class Program
    {
        static void Main()
        {
            //BaseClass o = new BaseClass();
        }
    }

    //abstract    can inherit cannot instantiate
    //sealed      cannot inherit can instantiate
    public sealed class SealedClass
    {

    }
}