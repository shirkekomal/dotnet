﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Default2 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            SqlConnection cn = new SqlConnection();
            cn.ConnectionString = @"Data Source=(localdb)\Projects;Initial Catalog=DotnetTraining;Integrated Security=True;MultipleActiveResultSets=true";
            cn.Open();

            SqlCommand cmd = new SqlCommand();
            cmd.Connection = cn;
            cmd.CommandText = "select * from Departments";

            SqlDataAdapter da = new SqlDataAdapter();
            da.SelectCommand = cmd;

            DataSet ds= new DataSet();
            da.Fill(ds, "Deps");

            cmd.CommandText = "select * from Employees";
            da.Fill(ds, "Emps");

            //add a primary key constraint
            DataColumn[] arrCols = new DataColumn[1];
            arrCols[0] = ds.Tables["Emps"].Columns["EmpNo"];
            ds.Tables["Emps"].PrimaryKey = arrCols;

            //adding a DataRelation
            ds.Relations.Add(
                ds.Tables["Deps"].Columns["DeptNo"],
                ds.Tables["Emps"].Columns["DeptNo"]
                );

            //column level constraints
            //ds.Tables["Emps"].Columns["Name"].u


            Session["ds"] = ds;

            //GridView1.DataSource = ds.Tables[1];
            GridView1.DataSource = ds.Tables["Emps"];
            GridView1.DataBind();



        }
    }
    protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        DataSet ds = (DataSet)Session["ds"];
        string empno = GridView1.Rows[e.RowIndex].Cells[3].Text;

        ////for (int i = 0; i < ds.Tables["Emps"].Rows.Count; i++)
        ////{
        ////    if (ds.Tables["Emps"].Rows[i]["EmpNo"] == empno)
        ////    {
        ////        ds.Tables["Emps"].Rows[i].Delete();
        ////    }
        ////}

        foreach (DataRow drow in ds.Tables["Emps"].Rows)
        {
            if (drow.RowState != DataRowState.Deleted)
            {
                if (drow["EmpNo"].ToString() == empno)
                {
                    drow.Delete();
                    break;
                }
            }
        }
        GridView1.DataSource = ds.Tables["Emps"];
        GridView1.DataBind();


    }
    protected void GridView1_RowEditing(object sender, GridViewEditEventArgs e)
    {
        DataSet ds = (DataSet)Session["ds"];

        GridView1.EditIndex = e.NewEditIndex;

        GridView1.DataSource = ds.Tables["Emps"];
        GridView1.DataBind();
    }
    protected void GridView1_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        DataSet ds = (DataSet)Session["ds"];

        GridView1.EditIndex = -1;

        GridView1.DataSource = ds.Tables["Emps"];
        GridView1.DataBind();

    }
    protected void GridView1_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        DataSet ds = (DataSet)Session["ds"];

        //boundfield
        TextBox txtEmpNo = (TextBox)GridView1.Rows[e.RowIndex].Cells[3].Controls[0];
        //boundfield
        //TextBox txtName = (TextBox)GridView1.Rows[e.RowIndex].Cells[4].Controls[0];
        //templatefield
        TextBox txtName = (TextBox)GridView1.Rows[e.RowIndex].FindControl("TextBox1");


        TextBox txtBasic = (TextBox)GridView1.Rows[e.RowIndex].Cells[5].Controls[0];
        //TextBox txtDeptNo = (TextBox)GridView1.Rows[e.RowIndex].Cells[6].Controls[0];
        DropDownList ddl = (DropDownList)GridView1.Rows[e.RowIndex].FindControl("DropDownList1");

        foreach (DataRow drow in ds.Tables["Emps"].Rows)
        {
            if (drow.RowState != DataRowState.Deleted)
            {
                if (drow["EmpNo"].ToString() == txtEmpNo.Text)
                {
                    drow["Name"] = txtName.Text;
                    drow["Basic"] = txtBasic.Text;
                    drow["DeptNo"] = ddl.SelectedValue;
                    break;
                }
            }
        }
        GridView1.EditIndex = -1;
        GridView1.DataSource = ds.Tables["Emps"];
        GridView1.DataBind();

    }

    protected DataTable GetDepts()
    {
        DataSet ds = (DataSet)Session["ds"];
        return ds.Tables["Deps"];
    }


    protected void Button1_Click(object sender, EventArgs e)
    {
        DataSet ds = (DataSet)Session["ds"];
        TextBox txtEmpNo = (TextBox)GridView1.FooterRow.FindControl("TextBox2");
        TextBox txtName = (TextBox)GridView1.FooterRow.FindControl("TextBox3");
        TextBox txtBasic = (TextBox)GridView1.FooterRow.FindControl("TextBox4");
        //TextBox txtDeptNo = (TextBox)GridView1.FooterRow.FindControl("TextBox5");
        DropDownList ddl = (DropDownList)GridView1.FooterRow.FindControl("DropDownList2");

        DataRow drow = ds.Tables["Emps"].NewRow();
        drow["EmpNo"] = txtEmpNo.Text;
        drow["Name"] = txtName.Text;
        drow["Basic"] = txtBasic.Text;
        drow["DeptNo"] = ddl.SelectedValue;
        //drow["DeptNo"] = txtDeptNo.Text;

        ds.Tables["Emps"].Rows.Add(drow);

        GridView1.DataSource = ds.Tables["Emps"];
        GridView1.DataBind();

    }
    protected void DropDownList2_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void GridView1_RowCreated(object sender, GridViewRowEventArgs e)
    {        
        DataSet ds = (DataSet)Session["ds"];

        if (e.Row.RowType == DataControlRowType.Footer)
        {
            DropDownList ddl = (DropDownList)e.Row.FindControl("DropDownList2");
            ddl.DataSource = ds.Tables["Deps"];
            ddl.DataTextField = "DeptName";
            ddl.DataValueField= "DeptNo";
            ddl.DataBind();
        }
    }
    protected void GridView1_Sorting(object sender, GridViewSortEventArgs e)
    {
        DataSet ds = (DataSet)Session["ds"];
        //DataView dv = new DataView(ds.Tables["Emps"]);
        //dv.Sort = e.SortExpression;
        //GridView1.DataSource = dv;
        //GridView1.DataBind();
        ds.Tables["Emps"].DefaultView.Sort = e.SortExpression;
        GridView1.DataSource = ds.Tables["Emps"];
        GridView1.DataBind();
    }
    protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        DataSet ds = (DataSet)Session["ds"];

        GridView1.PageIndex = e.NewPageIndex;

        GridView1.DataSource = ds.Tables["Emps"];
        GridView1.DataBind();

    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        DataSet ds = (DataSet)Session["ds"];

        SqlConnection cn = new SqlConnection();
        cn.ConnectionString = @"Data Source=(localdb)\Projects;Initial Catalog=DotnetTraining;Integrated Security=True;MultipleActiveResultSets=true";
        cn.Open();

        SqlCommand cmdInsert = new SqlCommand();
        cmdInsert.Connection = cn;
        cmdInsert.CommandText = "Insert into Employees values(@EmpNo,@Name,@Basic,@DeptNo)";
        //SqlParameter p;
        //p = new SqlParameter();
        //p.ParameterName = "@EmpNo";
        //p.SourceColumn = "EmpNo";
        //p.SourceVersion = DataRowVersion.Current;
        //cmdInsert.Parameters.Add(p);

        cmdInsert.Parameters.Add(new SqlParameter { ParameterName = "@EmpNo", SourceColumn = "EmpNo", SourceVersion = DataRowVersion.Current });
        cmdInsert.Parameters.Add(new SqlParameter { ParameterName = "@Name", SourceColumn = "Name", SourceVersion = DataRowVersion.Current });
        cmdInsert.Parameters.Add(new SqlParameter { ParameterName = "@Basic", SourceColumn = "Basic", SourceVersion = DataRowVersion.Current });
        cmdInsert.Parameters.Add(new SqlParameter { ParameterName = "@DeptNo", SourceColumn = "DeptNo", SourceVersion = DataRowVersion.Current });


        SqlCommand cmdUpdate = new SqlCommand();
        cmdUpdate.Connection = cn;
        cmdUpdate.CommandText = "Update Employees set Name =@Name,Basic=@Basic,DeptNo=@DeptNo where EmpNo =@EmpNo";

        cmdUpdate.Parameters.Add(new SqlParameter { ParameterName = "@Name", SourceColumn = "Name", SourceVersion = DataRowVersion.Current });
        cmdUpdate.Parameters.Add(new SqlParameter { ParameterName = "@Basic", SourceColumn = "Basic", SourceVersion = DataRowVersion.Current });
        cmdUpdate.Parameters.Add(new SqlParameter { ParameterName = "@DeptNo", SourceColumn = "DeptNo", SourceVersion = DataRowVersion.Current });
        cmdUpdate.Parameters.Add(new SqlParameter { ParameterName = "@EmpNo", SourceColumn = "EmpNo", SourceVersion = DataRowVersion.Original });

        SqlCommand cmdDelete = new SqlCommand();
        cmdDelete.Connection = cn;
        cmdDelete.CommandText = "Delete from Employees where EmpNo =@EmpNo";
        cmdDelete.Parameters.Add(new SqlParameter { ParameterName = "@EmpNo", SourceColumn = "EmpNo", SourceVersion = DataRowVersion.Original });

        SqlDataAdapter da = new SqlDataAdapter();
        da.InsertCommand = cmdInsert;
        da.UpdateCommand = cmdUpdate;
        da.DeleteCommand = cmdDelete;

        da.Update(ds, "Emps");


    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        DataSet ds = (DataSet)Session["ds"];

        SqlConnection cn = new SqlConnection();
        cn.ConnectionString = @"Data Source=(localdb)\Projects;Initial Catalog=DotnetTraining;Integrated Security=True;MultipleActiveResultSets=true";
        cn.Open();

        SqlCommand cmdInsert = new SqlCommand();
        cmdInsert.Connection = cn;
        cmdInsert.CommandText = "Insert into Employees values(@EmpNo,@Name,@Basic,@DeptNo)";
        //SqlParameter p;
        //p = new SqlParameter();
        //p.ParameterName = "@EmpNo";
        //p.SourceColumn = "EmpNo";
        //p.SourceVersion = DataRowVersion.Current;
        //cmdInsert.Parameters.Add(p);

        cmdInsert.Parameters.Add(new SqlParameter { ParameterName = "@EmpNo", SourceColumn = "EmpNo", SourceVersion = DataRowVersion.Current });
        cmdInsert.Parameters.Add(new SqlParameter { ParameterName = "@Name", SourceColumn = "Name", SourceVersion = DataRowVersion.Current });
        cmdInsert.Parameters.Add(new SqlParameter { ParameterName = "@Basic", SourceColumn = "Basic", SourceVersion = DataRowVersion.Current });
        cmdInsert.Parameters.Add(new SqlParameter { ParameterName = "@DeptNo", SourceColumn = "DeptNo", SourceVersion = DataRowVersion.Current });


        SqlCommand cmdUpdate = new SqlCommand();
        cmdUpdate.Connection = cn;
        cmdUpdate.CommandText = "Update Employees set Name =@Name,Basic=@Basic,DeptNo=@DeptNo where EmpNo =@EmpNo";

        cmdUpdate.Parameters.Add(new SqlParameter { ParameterName = "@Name", SourceColumn = "Name", SourceVersion = DataRowVersion.Current });
        cmdUpdate.Parameters.Add(new SqlParameter { ParameterName = "@Basic", SourceColumn = "Basic", SourceVersion = DataRowVersion.Current });
        cmdUpdate.Parameters.Add(new SqlParameter { ParameterName = "@DeptNo", SourceColumn = "DeptNo", SourceVersion = DataRowVersion.Current });
        cmdUpdate.Parameters.Add(new SqlParameter { ParameterName = "@EmpNo", SourceColumn = "EmpNo", SourceVersion = DataRowVersion.Original });

        SqlCommand cmdDelete = new SqlCommand();
        cmdDelete.Connection = cn;
        cmdDelete.CommandText = "Delete from Employees where EmpNo =@EmpNo";
        cmdDelete.Parameters.Add(new SqlParameter { ParameterName = "@EmpNo", SourceColumn = "EmpNo", SourceVersion = DataRowVersion.Original });

        SqlDataAdapter da = new SqlDataAdapter();
        da.InsertCommand = cmdInsert;
        da.UpdateCommand = cmdUpdate;
        da.DeleteCommand = cmdDelete;

        DataSet dsWithChanges = ds.GetChanges();
        //DataSet dsWithChanges = ds.GetChanges(DataRowState.Modified);

        da.ContinueUpdateOnError = true;
        da.Update(dsWithChanges, "Emps");

        //ds.AcceptChanges
        //ds.RejectChanges

    }
}