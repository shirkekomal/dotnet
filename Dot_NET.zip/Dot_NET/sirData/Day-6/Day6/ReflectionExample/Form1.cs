﻿using System;
using System.Reflection;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ReflectionExample
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            openFileDialog1.ShowDialog();
        }

        private void openFileDialog1_FileOk(object sender, CancelEventArgs e)
        {
            //MessageBox.Show(openFileDialog1.FileName);

            //TreeNode rootNode = treeView1.Nodes.Add("AssemblyName");
            //TreeNode classNode = rootNode.Nodes.Add("Class1");
            //TreeNode methodNode = classNode.Nodes.Add("Method1");

            Assembly asm = Assembly.LoadFile(openFileDialog1.FileName);
            AssemblyName asmName = asm.GetName();
            TreeNode rootNode = treeView1.Nodes.Add(asmName.Name);

            Type[] arrTypes = asm.GetTypes();
            foreach (Type t in arrTypes)
            {
                TreeNode classNode = rootNode.Nodes.Add( t.Name );
                MethodInfo[] arrMethods = t.GetMethods();
                foreach (MethodInfo m in arrMethods)
                {
                    TreeNode methodNode = classNode.Nodes.Add(m.Name);
                    //m.GetParameters()
                }

            }


        }
    }
}
