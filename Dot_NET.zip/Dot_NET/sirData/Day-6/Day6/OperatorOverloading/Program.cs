﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OperatorOverloading
{
    class Program
    {
        static void Main()
        {
            Employee o1 = new Employee { Basic = 1000, Name = "V", EmpNo = 1};
            o1 = o1 + 1000;
            Console.WriteLine(o1.Basic);

            Employee o2 = new Employee { Basic = 1000, Name = "V", EmpNo = 2 };

            Console.WriteLine(o1 >o2);

            o1++;
            Console.WriteLine(o1.Basic);

            Console.ReadLine();
        }
    }

    class Employee
    {
        public static Employee operator +(Employee e1, Decimal d)
        {
            Employee o = new Employee();
            o.Name = e1.Name;
            o.EmpNo = e1.EmpNo;
            o.Basic = e1.Basic + d;
            return o;
        }
        public static bool operator >(Employee e1, Employee e2)
        {
            return e1.Basic > e2.Basic;
        }
        public static bool operator <(Employee e1, Employee e2)
        {
            return e1.Basic < e2.Basic;
        }
        public static Employee operator ++(Employee e1)
        {
            e1.Basic++;
            return e1;
        }

        private int empNo;

        public int EmpNo
        {
            get { return empNo; }
            set { empNo = value; }
        }
        private string name;

        public string Name
        {
            get { return name; }
            set { name = value; }
        }
        private decimal basic;

        public decimal Basic
        {
            get { return basic; }
            set { basic = value; }
        }

    }
}
