﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CheckedUnchecked
{
    class Program
    {
        static void Main()
        {
            //Project Properties -> Build Tab -> Advanced button -> Check for overflow
            //checked {
            unchecked{
                byte b = 255;
                b++;
                Console.WriteLine(b);
            }
            Console.ReadLine();
        }
    }
}
