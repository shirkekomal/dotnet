﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            txtFullName.Text = txtFirstName.Text + " " + txtLastName.Text;
        }

        private void txtFirstName_KeyPress(object sender, KeyPressEventArgs e)
        {
           //MessageBox.Show(((TextBox) sender).Name);
            //MessageBox.Show(e.KeyChar.ToString());
            if( char.IsDigit(e.KeyChar)  )
                e.Handled = true;

        }

        private void txtFirstName_TextChanged(object sender, EventArgs e)
        {
            txtFullName.Text = txtFirstName.Text + " " + txtLastName.Text;
        }

        private void txtLastName_TextChanged(object sender, EventArgs e)
        {
            txtFullName.Text = txtFirstName.Text + " " + txtLastName.Text;

        }
    }
}
