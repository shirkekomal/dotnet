﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DelegatesFuncEtc
{
    class Program
    {
        static void Main1()
        {
            //void ()
            Action objDel = Display;
            objDel();
            Console.WriteLine();
            Action<string> objDel2 = new Action<string>(Display);
            objDel2("Hello");
            Console.WriteLine();
            Action<string, int, short> objDel3 = new Action<string, int, short>(Display);
            objDel3("a", 10, 2);
            Console.ReadLine();
        }
        static void Main2()
        {
            //Func<int, int, int> objDel = new Func<int, int, int>(Add);
            Func<int, int, int> objDel = Add;
            Console.WriteLine(objDel(10, 20));
            Console.WriteLine();
            Func<string, decimal, int> objDel2 = DoSomething;
            Console.WriteLine(objDel2("a",1));
            Console.ReadLine();
        }
        static void Main()
        {
            //Predicate<string> objDel = new Predicate<string>()
            Predicate<int> objDel = IsEven;
            Console.WriteLine(objDel(1));

            Console.ReadLine();
        }
        static void Display()
        {
            Console.WriteLine("Display");
        }
        static void Display(string s)
        {
            Console.WriteLine("Display" + s);
        }
        static void Display(string s,int i, short sh)
        {
            Console.WriteLine("Display" + s);
        }

        static int Add(int a, int b)
        {
            return a + b;
        }
        static int DoSomething(string a, decimal b)
        {
            return 0;
        }
        static bool IsEven(int a)
        {
            return (a % 2==0);
        }
    }

}
