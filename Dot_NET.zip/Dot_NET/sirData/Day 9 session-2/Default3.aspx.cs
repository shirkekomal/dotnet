﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Default3 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            SqlConnection cn = new SqlConnection();
            cn.ConnectionString = @"Data Source=(localdb)\Projects;Initial Catalog=DotnetTraining;Integrated Security=True;MultipleActiveResultSets=true";
            cn.Open();

            SqlCommand cmd = new SqlCommand();
            cmd.Connection = cn;
            cmd.CommandText = "select * from Departments";

            SqlDataAdapter da = new SqlDataAdapter();
            da.SelectCommand = cmd;

            DataSet ds = new DataSet();
            da.Fill(ds, "Deps");

            cmd.CommandText = "select * from Employees";
            da.Fill(ds, "Emps");

            //add a primary key constraint
            DataColumn[] arrCols = new DataColumn[1];
            arrCols[0] = ds.Tables["Emps"].Columns["EmpNo"];
            ds.Tables["Emps"].PrimaryKey = arrCols;

            //adding a DataRelation
            ds.Relations.Add(
                ds.Tables["Deps"].Columns["DeptNo"],
                ds.Tables["Emps"].Columns["DeptNo"]
                );

            //column level constraints
            //ds.Tables["Emps"].Columns["Name"].u


            Session["ds"] = ds;
            DataList1.DataSource = ds.Tables["Deps"];
            DataList1.DataBind();
            cn.Close();


        }

    }
    protected void DataList1_ItemDataBound(object sender, DataListItemEventArgs e)
    {
        DataSet ds = (DataSet)Session["ds"];
        GridView grd =(GridView) e.Item.FindControl("GridView1");

        //if value required is stored in a control
        //Label lblDeptNo = (Label)e.Item.FindControl("Label2");
        //string strDeptNo = lblDeptNo.Text;

        //if value required is not stored in a control
        //DataBinder.Eval(e.Item.DataItem, "DeptNo");
        string strDeptNo= DataBinder.Eval(e.Item, "DataItem.DeptNo").ToString();

        ds.Tables["Emps"].DefaultView.RowFilter = "DeptNo=" + strDeptNo;

        grd.DataSource = ds.Tables["Emps"];
        grd.DataBind();
    }
}