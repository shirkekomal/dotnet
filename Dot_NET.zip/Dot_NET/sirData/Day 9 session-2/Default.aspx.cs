﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        //SqlConnection cn = new SqlConnection("Data Source=(localdb)\Projects;Initial Catalog=DotnetTraining;Integrated Security=True");
        //Data Source=(localdb)\Projects;Initial Catalog=DotnetTraining;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False
        SqlConnection cn = new SqlConnection();
        //cn.ConnectionString = @"Data Source=(localdb)\Projects;Initial Catalog=DotnetTraining;User Id=sa;Password=sa1";
        cn.ConnectionString = @"Data Source=(localdb)\Projects;Initial Catalog=DotnetTraining;Integrated Security=True";

        cn.Open();
        cn.Close();
        Response.Write("opened successfully");

    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        SqlConnection cn = new SqlConnection();
        cn.ConnectionString = @"Data Source=(localdb)\Projects;Initial Catalog=DotnetTraining;Integrated Security=True";
        cn.Open();

        SqlCommand cmdInsert = new SqlCommand();
        cmdInsert.Connection = cn;
        //cmdInsert.CommandText = "insert into Employees values(10,'aaa',12345,20)";
        cmdInsert.CommandText = "insert into Employees values(" 
            +TextBox1.Text + ",'" + TextBox2.Text + "'," 
            + TextBox3.Text + "," + TextBox4.Text + ")";

        cmdInsert.ExecuteNonQuery();

        cn.Close();

    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        SqlConnection cn = new SqlConnection();
        cn.ConnectionString = @"Data Source=(localdb)\Projects;Initial Catalog=DotnetTraining;Integrated Security=True";
        cn.Open();

        SqlCommand cmdInsert = new SqlCommand();
        cmdInsert.Connection = cn;
        cmdInsert.CommandText = "insert into Employees values(@EmpNo,@Name,@Basic,@DeptNo)";

        cmdInsert.CommandType = System.Data.CommandType.Text;
        
        cmdInsert.Parameters.AddWithValue("@EmpNo", TextBox1.Text);
        cmdInsert.Parameters.AddWithValue("@Name", TextBox2.Text);
        cmdInsert.Parameters.AddWithValue("@Basic", TextBox3.Text);
        cmdInsert.Parameters.AddWithValue("@DeptNo", TextBox4.Text);
        cmdInsert.ExecuteNonQuery();
        cn.Close();

    }
    protected void Button4_Click(object sender, EventArgs e)
    {
        SqlConnection cn = new SqlConnection();
        cn.ConnectionString = @"Data Source=(localdb)\Projects;Initial Catalog=DotnetTraining;Integrated Security=True";
        cn.Open();

        SqlCommand cmdInsert = new SqlCommand();
        cmdInsert.Connection = cn;
        cmdInsert.CommandText = "InsertEmployee";
        
        cmdInsert.CommandType = CommandType.StoredProcedure;

        cmdInsert.Parameters.AddWithValue("@EmpNo", TextBox1.Text);
        cmdInsert.Parameters.AddWithValue("@Name", TextBox2.Text);
        cmdInsert.Parameters.AddWithValue("@Basic", TextBox3.Text);
        cmdInsert.Parameters.AddWithValue("@DeptNo", TextBox4.Text);
        cmdInsert.ExecuteNonQuery();
        cn.Close();
    }
    protected void Button5_Click(object sender, EventArgs e)
    {
        SqlConnection cn = new SqlConnection();
        cn.ConnectionString = @"Data Source=(localdb)\Projects;Initial Catalog=DotnetTraining;Integrated Security=True";
        cn.Open();

        SqlCommand cmd = new SqlCommand();
        cmd.Connection = cn;
        cmd.CommandText = "select count(*)from Employees";

        Label5.Text = cmd.ExecuteScalar().ToString();
        cn.Close();
    }
    protected void Button6_Click(object sender, EventArgs e)
    {
        SqlConnection cn = new SqlConnection();
        cn.ConnectionString = @"Data Source=(localdb)\Projects;Initial Catalog=DotnetTraining;Integrated Security=True";
        cn.Open();

        SqlCommand cmd = new SqlCommand();
        cmd.Connection = cn;
        cmd.CommandText = "select * from Employees";

        SqlDataReader dr = cmd.ExecuteReader();

        while (dr.Read())
            ListBox1.Items.Add(dr["Name"].ToString());
        dr.Close();

        cn.Close();
    }
    protected void Button7_Click(object sender, EventArgs e)
    {
        SqlConnection cn = new SqlConnection();
        cn.ConnectionString = @"Data Source=(localdb)\Projects;Initial Catalog=DotnetTraining;Integrated Security=True";
        cn.Open();

        SqlCommand cmd = new SqlCommand();
        cmd.Connection = cn;
        cmd.CommandText = "select * from Employees;select * from Departments";

        SqlDataReader dr = cmd.ExecuteReader();

        while (dr.Read())
            ListBox1.Items.Add(dr["Name"].ToString());
        
        dr.NextResult();
        ListBox1.Items.Add("----------");

        while (dr.Read())
            ListBox1.Items.Add(dr["DeptName"].ToString());

        dr.Close();

        cn.Close();

    }
    protected void Button8_Click(object sender, EventArgs e)
    {
        SqlConnection cn = new SqlConnection();
        cn.ConnectionString = @"Data Source=(localdb)\Projects;Initial Catalog=DotnetTraining;Integrated Security=True;MultipleActiveResultSets=true";
        cn.Open();

        SqlCommand cmd = new SqlCommand();
        cmd.Connection = cn;
        cmd.CommandText = "select * from Departments";

        SqlCommand cmd2 = new SqlCommand();
        cmd2.Connection = cn;

        SqlDataReader dr = cmd.ExecuteReader();

        while (dr.Read())
        {
            ListBox1.Items.Add(dr["DeptName"].ToString());
            cmd2.CommandText = "select * from Employees where DeptNo = " + dr["DeptNo"].ToString();
            SqlDataReader dr2 = cmd2.ExecuteReader();
            while(dr2.Read())
            {
                ListBox1.Items.Add("------" + dr2["Name"].ToString());
            }
            dr2.Close();
        }

        dr.Close();

        cn.Close();


    }
    protected void Button9_Click(object sender, EventArgs e)
    {
        SqlDataReader dr = GetDr();
        while (dr.Read())
            ListBox1.Items.Add(dr["DeptName"].ToString());
        dr.Close(); // will close the underlying connection when the dr is closed 
        //- due to the CommandBehavior.CloseConnection option while opening the dr
    }

    private SqlDataReader GetDr()
    {
        SqlConnection cn = new SqlConnection();
        cn.ConnectionString = @"Data Source=(localdb)\Projects;Initial Catalog=DotnetTraining;Integrated Security=True;MultipleActiveResultSets=true";
        cn.Open();

        SqlCommand cmd = new SqlCommand();
        cmd.Connection = cn;
        cmd.CommandText = "select * from Departments";
        SqlDataReader dr = cmd.ExecuteReader(CommandBehavior.CloseConnection);

        return dr;
    }
    protected void Button10_Click(object sender, EventArgs e)
    {
        SqlConnection cn = new SqlConnection();
        cn.ConnectionString = @"Data Source=(localdb)\Projects;Initial Catalog=DotnetTraining;Integrated Security=True";
        cn.Open();

        SqlCommand cmd = new SqlCommand();
        cmd.Connection = cn;
        cmd.CommandText = "select * from Departments;select * from Departments;select * from Departments";

        SqlDataReader dr = cmd.ExecuteReader();
        RadioButtonList1.DataSource = dr;
        RadioButtonList1.DataTextField = "DeptName";
        RadioButtonList1.DataValueField= "DeptNo";
        RadioButtonList1.DataBind();

        dr.NextResult();

        CheckBoxList1.DataSource = dr;
        CheckBoxList1.DataTextField = "DeptName";
        CheckBoxList1.DataValueField = "DeptNo";
        CheckBoxList1.DataBind();

        dr.NextResult();

        DropDownList1.DataSource = dr;
        DropDownList1.DataTextField = "DeptName";
        DropDownList1.DataValueField = "DeptNo";
        DropDownList1.DataBind();



        dr.Close();
        cn.Close();

    }
    protected void Button11_Click(object sender, EventArgs e)
    {
        Label6.Text = RadioButtonList1.SelectedItem.Text;
        //Label7.Text = RadioButtonList1.SelectedItem.Value;
        Label7.Text = RadioButtonList1.SelectedValue;

    }
    protected void Button12_Click(object sender, EventArgs e)
    {
        RadioButtonList1.SelectedValue = "30";
    }
    protected void Button13_Click(object sender, EventArgs e)
    {
        Label6.Text = "";
        foreach (ListItem li in CheckBoxList1.Items)
        {
            if (li.Selected)
            {
                Label6.Text += li.Value + ",";
            }
        }
    }
    protected void Button14_Click(object sender, EventArgs e)
    {
        SqlConnection cn = new SqlConnection();
        cn.ConnectionString = @"Data Source=(localdb)\Projects;Initial Catalog=DotnetTraining;Integrated Security=True";
        cn.Open();

        SqlTransaction t = cn.BeginTransaction();

        SqlCommand cmdInsert = new SqlCommand();
        cmdInsert.Connection = cn;
        cmdInsert.Transaction = t;
        cmdInsert.CommandText = "insert into Employees values(21,'aaa',12345,20)";

        SqlCommand cmdInsert2 = new SqlCommand();
        cmdInsert2.Transaction = t;
        cmdInsert2.Connection = cn;
        cmdInsert2.CommandText = "insert into Employees values(20,'aaa',12345,20)";

        try
        {
            cmdInsert.ExecuteNonQuery();
            cmdInsert2.ExecuteNonQuery();
            t.Commit();
            Label6.Text = "Commit";
        }
        catch
        {
            t.Rollback();
            Label6.Text = "Rollback";
        }
        cn.Close();
    }
}