﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Default4 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            SqlConnection cn = new SqlConnection();
            cn.ConnectionString = @"Data Source=(localdb)\Projects;Initial Catalog=DotnetTraining;Integrated Security=True;MultipleActiveResultSets=true";
            cn.Open();

            SqlCommand cmd = new SqlCommand();
            cmd.Connection = cn;
            cmd.CommandText = "select * from Departments";

            SqlDataAdapter da = new SqlDataAdapter();
            da.SelectCommand = cmd;

            DataSet ds = new DataSet();
            da.Fill(ds, "Deps");

            cmd.CommandText = "select * from Employees";
            da.Fill(ds, "Emps");

            //add a primary key constraint
            DataColumn[] arrCols = new DataColumn[1];
            arrCols[0] = ds.Tables["Emps"].Columns["EmpNo"];
            ds.Tables["Emps"].PrimaryKey = arrCols;

            //adding a DataRelation
            ds.Relations.Add(
                ds.Tables["Deps"].Columns["DeptNo"],
                ds.Tables["Emps"].Columns["DeptNo"]
                );

            //column level constraints
            //ds.Tables["Emps"].Columns["Name"].u


            Session["ds"] = ds;
            DataList1.DataSource = ds.Tables["Deps"];
            DataList1.DataBind();
            cn.Close();


        }


    }
    protected void DataList1_DeleteCommand(object source, DataListCommandEventArgs e)
    {
        Label lblDeptNo =(Label) e.Item.FindControl("Label2");
        Response.Write(lblDeptNo.Text);
    }
    protected void DataList1_EditCommand(object source, DataListCommandEventArgs e)
    {
        DataSet ds = (DataSet)Session["ds"];
        DataList1.EditItemIndex = e.Item.ItemIndex;
        DataList1.DataSource = ds.Tables["Deps"];
        DataList1.DataBind();
    }
    protected void DataList1_UpdateCommand(object source, DataListCommandEventArgs e)
    {

    }
    protected void DataList1_CancelCommand(object source, DataListCommandEventArgs e)
    {

    }
    protected void DataList1_ItemCommand(object source, DataListCommandEventArgs e)
    {
       // e.CommandName;
    }
}