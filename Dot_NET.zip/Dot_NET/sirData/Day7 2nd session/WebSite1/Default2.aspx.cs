﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Default2 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //code for server.transfer
        //Label1.Text = Request.Form["txtFirstName"];

        //code for response.redirect with a querystring
        //Label1.Text = Request.QueryString["firstname"];

        //code for response.redirect with cookies
        //HttpCookie objCookie = Request.Cookies["ChocoChip"];
        //if (objCookie != null)
        //{
        //    //Label1.Text = objCookie.Value;
        //    Label1.Text = objCookie.Values["firstname"];
        //}
        //else
        //    Label1.Text = "cookie missing";

        //code for response.redirect with session variable
       // Label1.Text = Session["firstname"].ToString();

        //code for PostbackUrl
        //Label1.Text = Request.Form["txtFirstName"];

        //code for PostbackUrl with <%@ PreviousPageType....>
        //TextBox txtFirstName = (TextBox)PreviousPage.FindControl("txtFirstName");
        //Label1.Text = txtFirstName.Text;

        //code for PostbackUrl with <%@ PreviousPageType....> and property on first page
        //TextBox txtFirstName = PreviousPage.TextBoxFirstName;
        //Label1.Text = txtFirstName.Text;
        //Label1.Text = PreviousPage.TextBoxFirstName.Text;


    }
}