﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        //SqlConnection cn = new SqlConnection("Data Source=(localdb)\Projects;Initial Catalog=DotnetTraining;Integrated Security=True");
        //Data Source=(localdb)\Projects;Initial Catalog=DotnetTraining;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False
        SqlConnection cn = new SqlConnection();
        //cn.ConnectionString = @"Data Source=(localdb)\Projects;Initial Catalog=DotnetTraining;User Id=sa;Password=sa1";
        cn.ConnectionString = @"Data Source=(localdb)\Projects;Initial Catalog=DotnetTraining;Integrated Security=True";

        cn.Open();
        cn.Close();
        Response.Write("opened successfully");

    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        SqlConnection cn = new SqlConnection();
        cn.ConnectionString = @"Data Source=(localdb)\Projects;Initial Catalog=DotnetTraining;Integrated Security=True";
        cn.Open();

        SqlCommand cmdInsert = new SqlCommand();
        cmdInsert.Connection = cn;
        //cmdInsert.CommandText = "insert into Employees values(10,'aaa',12345,20)";
        cmdInsert.CommandText = "insert into Employees values(" 
            +TextBox1.Text + ",'" + TextBox2.Text + "'," 
            + TextBox3.Text + "," + TextBox4.Text + ")";

        cmdInsert.ExecuteNonQuery();

        cn.Close();

    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        SqlConnection cn = new SqlConnection();
        cn.ConnectionString = @"Data Source=(localdb)\Projects;Initial Catalog=DotnetTraining;Integrated Security=True";
        cn.Open();

        SqlCommand cmdInsert = new SqlCommand();
        cmdInsert.Connection = cn;
        cmdInsert.CommandText = "insert into Employees values(@EmpNo,@Name,@Basic,@DeptNo)";

        cmdInsert.CommandType = System.Data.CommandType.Text;
        
        cmdInsert.Parameters.AddWithValue("@EmpNo", TextBox1.Text);
        cmdInsert.Parameters.AddWithValue("@Name", TextBox2.Text);
        cmdInsert.Parameters.AddWithValue("@Basic", TextBox3.Text);
        cmdInsert.Parameters.AddWithValue("@DeptNo", TextBox4.Text);
        cmdInsert.ExecuteNonQuery();
        cn.Close();

    }
    protected void Button4_Click(object sender, EventArgs e)
    {
        SqlConnection cn = new SqlConnection();
        cn.ConnectionString = @"Data Source=(localdb)\Projects;Initial Catalog=DotnetTraining;Integrated Security=True";
        cn.Open();

        SqlCommand cmdInsert = new SqlCommand();
        cmdInsert.Connection = cn;
        cmdInsert.CommandText = "InsertEmployee";
        
        cmdInsert.CommandType = CommandType.StoredProcedure;

        cmdInsert.Parameters.AddWithValue("@EmpNo", TextBox1.Text);
        cmdInsert.Parameters.AddWithValue("@Name", TextBox2.Text);
        cmdInsert.Parameters.AddWithValue("@Basic", TextBox3.Text);
        cmdInsert.Parameters.AddWithValue("@DeptNo", TextBox4.Text);
        cmdInsert.ExecuteNonQuery();
        cn.Close();
    }
    protected void Button5_Click(object sender, EventArgs e)
    {
        SqlConnection cn = new SqlConnection();
        cn.ConnectionString = @"Data Source=(localdb)\Projects;Initial Catalog=DotnetTraining;Integrated Security=True";
        cn.Open();

        SqlCommand cmd = new SqlCommand();
        cmd.Connection = cn;
        cmd.CommandText = "select count(*)from Employees";

        Label5.Text = cmd.ExecuteScalar().ToString();
        cn.Close();
    }
}