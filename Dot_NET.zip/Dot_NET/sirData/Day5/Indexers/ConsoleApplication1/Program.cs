﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    public class MyArray : IEnumerable
    {
        int[] arr;
        public MyArray()
        {
            arr = new int[3];
        }
        public int this[int index]
        {
            get { return arr[index]; }
            set { arr[index] = value; }
        }


        public IEnumerator GetEnumerator()
        {
            return arr.GetEnumerator();
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            MyArray obj = new MyArray();
            obj[0] = 100;
            obj[1] = 200;
            obj[2] = 300;
            //Console.WriteLine(obj[0]);
            foreach (int i in obj)
            {
                Console.WriteLine(i);
            }
            Console.ReadLine();
        }
    }
}
