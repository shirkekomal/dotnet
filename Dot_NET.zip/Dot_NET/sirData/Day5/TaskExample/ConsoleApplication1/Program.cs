﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ConsoleApplication1
{

    class Program
    {
        const int MAX = 100;
        static void Main1()
        {
            Task t1 = new Task(Func1);
            Task t2 = new Task(Func2);
           // Task t3 = Task.Factory.StartNew(Func3);
            t1.Start();
            t2.Start();
            for (int i = 0; i < MAX; i++)
            {
                Console.WriteLine("main:" + i);
            }
            Console.ReadLine();

        }
        static void Func1()
        {
            for (int i = 0; i < MAX; i++)
            {
                Console.WriteLine("First:" + i);
            }
        }
        static void Func2()
        {
            for (int i = 0; i < MAX; i++)
            {
                Console.WriteLine("Second:" + i);
            }
        }
    }
}
namespace ConsoleApplication2
{

    class Program
    {
        static void Main1()
        {
            Task<int> t1 = new Task<int>(DoSomething);

            t1.Start();
            Console.WriteLine("finish other code...");
            Console.WriteLine(t1.Result);
            Console.ReadLine();

        }
        static int DoSomething()
        {
            Thread.Sleep(3000);
            return 1;
        }
    }
}
namespace ConsoleApplication3
{
    class Program
    {
        static void Main2()
        {
            Task<int> t1 = new Task<int>(DoSomething,10);

            t1.Start();
            Console.WriteLine("finish other code...");
            Console.WriteLine(t1.Result);
            Console.ReadLine();

        }
        static int DoSomething(object o)
        {
            int i = (int)o;
            Thread.Sleep(3000);
            return i * 2;
        }
    }
}
