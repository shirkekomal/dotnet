﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        SqlConnection cn = new SqlConnection();
        //cn.ConnectionString = @""Data Source=(localdb)\Projects;Initial Catalog=DotNet;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False";
        cn.ConnectionString = @"Data Source=(localdb)\Projects;Initial Catalog=DotNet;Integrated Security=True";
        cn.Open();
        Response.Write("Coneetion done11");
        SqlCommand cmdInsert = new SqlCommand();

        cmdInsert.Connection = cn;

        cmdInsert.CommandText = "insert into Departments values(@)ID , @Name)";
        cmdInsert.Parameters.AddWithValue("@Id", TextBox1.Text);
        cmdInsert.Parameters.AddWithValue("@Name", TextBox2.Text);
        
        cmdInsert.ExecuteNonQuery();
        cn.Close();
    }

    protected void Button2_Click(object sender, EventArgs e)
    {
        SqlConnection cn = new SqlConnection();
        //cn.ConnectionString = @""Data Source=(localdb)\Projects;Initial Catalog=DotNet;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False";
        cn.ConnectionString = @"Data Source=(localdb)\Projects;Initial Catalog=DotNet;Integrated Security=True";
        cn.Open();
        Response.Write("Coneetion done11");
        SqlCommand cmdInsert = new SqlCommand();
        
        cmdInsert.Connection = cn;
      cmdInsert.CommandText = "insert into HobbieMaster values("+ TextBox1.Text + ",'" + TextBox2.Text + "' )";
       // cmdInsert.CommandText = "insert into Departments values(,'aaa')";
        cmdInsert.ExecuteNonQuery();    
        cn.Close();

        cmdInsert.CommandText = "insert into Departments values()";

    }
    protected void TextBox2_TextChanged(object sender, EventArgs e)
    {

    }
}