﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Employee : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        SqlConnection cs=new SqlConnection();
        cs.ConnectionString=@"Data Source=(localdb)\Projects;Initial Catalog=DotNet;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False";
      //  Data Source=(localdb)\Projects;Initial Catalog=DotNet;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False
        cs.Open();
        Response.Write("Connection is done");
        SqlCommand cmdInsert=new SqlCommand();
        cmdInsert.Connection=cs;
        cmdInsert.CommandText = "insert into City_Master values(@CityId ,@CityName)";
        cmdInsert.Parameters.AddWithValue("@CityId", TextBox1.Text);
        cmdInsert.Parameters.AddWithValue("@CityName", TextBox2.Text);

        cmdInsert.ExecuteNonQuery();
        cs.Close();
    }
}