﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Basics1
{
    class Program
    {
        //trying functions
        static void Main1()
        {

            Console.WriteLine("Hello EveryOne");
            class1 o = new class1();
            o.i = 100;
            Console.WriteLine(o.i);
            o.Display();
            o.Display("KOMAL");
            Console.WriteLine("Addition"+o.sum(10, 20, 30));
            Console.WriteLine("Addition" + o.sum(10, 20, 30, 40));
            Console.WriteLine("Addition" + o.sum(10, 20));
            o.fun(1, 2, 3, 4, 5);
            o.fun(1, 2, 3);
            o.fun(1, 2, 3, 4, 5, 6, 7);
            Console.ReadLine();
        }

        //for property
        static void Main2()
        {
            class1 c = new class1();
            c.B = 100;
            Console.WriteLine("B-->>"+c.B);
            c.B1 = 60;
            Console.WriteLine("Validation B1-->>" + c.B1);
            c.B1 = 40;
            Console.WriteLine("Validation B1-->>" + c.B1);
            // c.B2 = 100; cannot be assign to it is read only
            Console.WriteLine("read only"+c.B2);
            //c.b3 = 100;
            Console.WriteLine("property accessor" + c.B3);
            //Console.WriteLine("property accessor"+c.B4);    get accessor is inaccessible.... private int B4.

            c.B5 = 20;
            Console.WriteLine("Automatic property"+c.B5);
            Console.ReadLine();
          
        }

        //for constructor        
        static void Main12()
        {
            class1 c = new class1();
            class1 c1 = new class1("abc","xyz");
            Console.WriteLine(c1.a+" "+c1.c);
            Console.ReadLine();
        }

        static void Main()
        {
            class1 cl = new class1();
           class1.k = 1000;
            Console.WriteLine("satatic value"+class1.k);
            class1.static_Display();
            
           Console.WriteLine("static getter setter"+(class1.Static_props=57.12f)); 
        }
        class class1
        {
            //  static void Main()
            //{
            //    class1 c = new class1();
            //    c.B3 = 90;
            //    Console.WriteLine("property accessor" + c.B3);
            //    Console.ReadLine();
            //}
            #region function

            public int i;
            public void Display()
            {
                Console.WriteLine("Class1 Disp");
            }

            public void Display(String s)
            {
                Console.WriteLine("Class1 Disp" + s);
            }

            //optional parameters
            public int sum(int a, int b, int c = 0, int d = 0)
            {
                return a + b + c + d;
            }

            //function with array ie no of param
            public void fun(params int[] p)
            {
                Console.WriteLine(p.Length);
                Console.WriteLine();
                Console.WriteLine("function with array");
                for (int i = 0; i < p.Length; i++)
                {
                    Console.WriteLine(p[i]);
                }
            }
            #endregion

            #region property
            //set get
            private int b;
            public int B
            {
                get
                {
                    return b;
                }
                set
                {
                    b = value;
                }
            }

            //set get Validation
            private int b1;
            public int B1
            {
                get
                {
                    return b1;
                }
                set
                {
                    if (value < 50)
                        b1 = value;
                    else
                        Console.WriteLine("value must be less than 50");
                }
            }

            //to make it read only
            private int b2;
            public int B2
            {
                get
                {
                    return b2;
                }
            }

            //read only using property accessor
            private int b3;
            public int B3
            {
                get
                {
                    return b3;
                }
                private set
                {
                    b3 = value;
                }
            }


            //private int b4;
            //private int B4
            //{
            //    get
            //    {
            //        return b4;
            //    }
            //    public set
            //    {
            //        b4 = value;
            //    }
            //}

            private int b5;
            public int B5
            {
                get { return b5; }
                set { b5 = value; }
            }
            #endregion

            #region constructor

            public String a;
            public String c;
            //public class1()
            //{

            //    Console.WriteLine("Default Constructor");
            //}

            public class1(String a, String b1)
            {
                Console.WriteLine("Parameterized Constructor");
                this.a = a;
                this.c = b1;
                Console.ReadLine();
            }

            //~class1()
            //{
            //    Console.WriteLine("destructor");
            //    Console.ReadLine();
            //}
            #endregion

            #region static

            public int x;
            public static int k;

            public static void static_Display()
            {
                Console.WriteLine("Static Display");
            }


            private static float static_props;
                public static float Static_props
                {

                  get { return class1.static_props; }
                  set { class1.static_props = value; }
                }


                static class1()
                {

                    string a = "komal";
                    Console.WriteLine("Static Method   " + a);
                }

                public class1()
                {
                    Console.WriteLine("Constructor ");
                }
            #endregion
        }
    }

}