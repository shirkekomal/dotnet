﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Inheritance
{

    public class Base
    {
        public int PUBLIC=10;
        private String PRIVATE="komal";
        protected float PROTECTED=3.4f;
        internal double INTERNAL=3.5;
        protected internal int PROTECTED_INTERNAL=100; 

        public Base()
        {
            Console.WriteLine("private of base s, assembly-->>"+this.PRIVATE);
            Console.WriteLine("Constructor of Base");
        }
    }

    public class DerivedSm:Base
    {
        public DerivedSm()
        {
            Console.WriteLine("Constructor of Derived class in same assembly");
          
        }
        public void show()
        {
            Console.WriteLine("Show mwethod of class in same assembly");
            Console.WriteLine("PUBLIC mem" + this.PUBLIC);
            Console.WriteLine("PROTECTED mem" + this.PROTECTED);
            Console.WriteLine("INTERNAL mem" + this.INTERNAL);
            Console.WriteLine("PROTECTED_INTERNAL mem" + this.PROTECTED_INTERNAL);
        }
    }


    public class Derived:InheritanceDemo.BaseAssembly

    {

        public int x;
        
        public Derived()
        {
            Console.WriteLine("Constructor of Derived");
           // this.
          
        }

        public void display1()
        {
            Console.WriteLine("Display method of derived");
            Console.WriteLine("protected Mem of base-->>"+this.PROTECTED);
            Console.WriteLine("PROTECTED_INTERNAL Mem of base-->>" + this.PROTECTED_INTERNAL);
            Console.WriteLine("PUBLIC Mem of base-->>" + this.PUBLIC);
            Console.WriteLine("<<------------------------------------------>>");
        }
    }

    class Program
    {

        static void Main1()
        {
            Derived d = new Derived();
          Console.WriteLine("Values"+d.PUBLIC);
            d.display1();
            Console.WriteLine("<<-------------------2---------------------->>");
            DerivedSm sm = new DerivedSm();
            Console.WriteLine("Derived sm pkg PUBLIC -->>" + sm.PUBLIC);
            Console.WriteLine("Derived sm pkg INTERNAL -->>" + sm.INTERNAL);
            Console.WriteLine("Derived sm pkg PROTECTED_INTERNAL -->>" + sm.PROTECTED_INTERNAL);
            sm.show();
            //Console.WriteLine("--->>"+d.);
            Console.ReadLine();
        }
    }
}
