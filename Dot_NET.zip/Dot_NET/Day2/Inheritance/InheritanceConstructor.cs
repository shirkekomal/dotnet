﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Inheritance
{
    public class Base1
    {
        int i;
        public Base1()
        {
            this.i = 0;
            Console.WriteLine("Default Constructor Base");
        }

        public Base1(int i)
        {
            this.i= i;
            Console.WriteLine("Para Constructor Base");
            Console.WriteLine("Base1  "+i);
        }
    }

    public class Derived1:Base1
    {
        int j;
        public Derived1()
        {
            this.j = 0;
            Console.WriteLine( "Derived1 Const Default");
        }
        
        public Derived1(int i,int j):base(i)
        {
        
            this.j=j;
            Console.WriteLine("Derived1 Const Para");
            Console.WriteLine("Derived1  "+j);
          
        }

    }
    class InheritanceConstructor
    {
        static void Main11()
        {
            Derived1 d = new Derived1(10,12);
        }
    }
}
