﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo
{
    public class Base
    {
        protected int x = 20;
        static void Main(string[] args)
 
    }

   
    class Program:Base
    {
        static void Main(string[] args)
        {
            Base b = new Program();
        }
    }
}
