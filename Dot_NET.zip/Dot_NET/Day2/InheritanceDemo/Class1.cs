﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InheritanceDemo
{
    public class BaseAssembly
    {
        public int PUBLIC=500;
        private String PRIVATE="koko";
        protected float PROTECTED=55.5f;
        internal double INTERNAL=23.5;
        protected internal int PROTECTED_INTERNAL=1000;

        public BaseAssembly()
        {
            Console.WriteLine("private of base-->>" + this.PRIVATE);
            Console.WriteLine("Constructor of Base Inheritance1");
        }
    }

    public class Class1
    {
    }
}
