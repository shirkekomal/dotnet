﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractClass
{

    public interface InterFaceFile
    {
        void Insert();
        void Update();
        void Delete();
    }

    public interface InterFaceOp
    {
        void Show();
        void Display();
        void Delete();
    }

    public class Class2:InterFaceFile,InterFaceOp
    {

        void InterFaceFile.Insert()
        {
            Console.WriteLine(" Insert InterFaceFile");
        }

        void InterFaceFile.Update()
        {
            Console.WriteLine(" Update InterFaceFile");
        }

        void InterFaceFile.Delete()
        {
            Console.WriteLine(" Delete InterFaceFile");
        }

        public void Show()
        {
            Console.WriteLine(" Show InterFaceOp");
        }

        public void Display()
        {
            Console.WriteLine(" Display InterFaceOp");
        }

        void InterFaceOp.Delete()
        {
            Console.WriteLine(" Delete InterFaceOp");
        }
    }

    class InterFace2
    {
        static void Main3(string[] args)
        {
            Class2 c = new Class2();
            InterFaceFile f;
            f = c;
            f.Insert();
            f.Update();
            f.Delete();
            Console.WriteLine("<------------------------->");
            InterFaceOp o;
            o = c;
            o.Display();
            o.Delete();
            o.Show();
        }

    }
}
