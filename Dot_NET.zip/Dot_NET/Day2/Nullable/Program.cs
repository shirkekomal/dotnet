﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Nullable
{
    class Program
    {
        static void Main(string[] args)
        {
            int ? a = 100;
            a = null;
            int b = 0;
            if (a == null)
                Console.WriteLine("NULL");
            else 
                b=a.Value;
            
            if(a.HasValue)
                b=a.Value;
            else
                Console.WriteLine("NULL");

            b=a.GetValueOrDefault();
            b=a.GetValueOrDefault(10);
        }
    }
}
