﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Enum
{
    class Program
    {
        public enum Days
        {
            Sunday,
            Monday,
            Tuesday,
        }

        static void Main(string[] args)
        {
            Days d1 = new Days();
            DisplayDay(Days.Sunday);
            Console.ReadLine();
        }

        static void DisplayDay(Days d)
        {
            if(d==Days.Monday)
            {
                Console.WriteLine("Today Is Monday");
            }
            else if(d==Days.Sunday)
            {
                Console.WriteLine("Enjoy Weekend");
            }
            else if(d==Days.Tuesday)
            {
                Console.WriteLine("As Usual");
            }
        }

    }
}
