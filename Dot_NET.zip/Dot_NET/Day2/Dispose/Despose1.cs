﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dispose
{
    public class Demo1 : IDisposable
    {
        private  static bool isDesposed;
        public void Display()
        {
            CheckForDesposed();
            Console.WriteLine("Display method ");
        }

        public void Dispose()
        {
            isDesposed=true;
            Console.WriteLine("Dispose Method calls");
        }
          public static void CheckForDesposed()
          {
              if (isDesposed)
                  throw new ObjectDisposedException("Demo1");
          }
    }

    class Despose1
    {
        static void Main(string[] args)
        {
            Demo1 d = new Demo1();
            using (d = new Demo1()) // used to despose the object after use
            {
                d.Display();
            }
            //d.Display();
        }
    }
}
