﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Register : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            SqlConnection cn = new SqlConnection(@"Data Source=(localdb)\Projects;Initial Catalog=koko;Integrated Security=True;");
            cn.Open();
            SqlCommand cmdIns = new SqlCommand();
            cmdIns.Connection = cn;
            //cmdIns.CommandText = "select * from CityMaster;select * from hobbyMaster;select *from PaymentModeMaster";
            cmdIns.CommandText = "select * from CityMaster";
            //cmdIns.CommandType = System.Data.CommandType.StoredProcedure;
            SqlDataReader dr = cmdIns.ExecuteReader();
            City.DataSource = dr;
            City.DataTextField = "CityName";
            City.DataValueField = "CityId";
            City.DataBind();
            dr.Close();

           // dr.NextResult();

            cmdIns.CommandText = "select * from HobbyMaster";
            //cmdIns.CommandType = System.Data.CommandType.StoredProcedure;
            SqlDataReader dr1 = cmdIns.ExecuteReader();
            CheckBoxListHobbies.DataSource = dr1;
            CheckBoxListHobbies.DataTextField = "HobbyName";
            CheckBoxListHobbies.DataValueField = "HobbyId";
            CheckBoxListHobbies.DataBind();
            dr1.Close();

            cmdIns.CommandText = "select * from PaymentModeMaster";
           // cmdIns.CommandType = System.Data.CommandType.StoredProcedure;
            SqlDataReader dr2 = cmdIns.ExecuteReader();
            RadioButtonListPaymentMode.DataSource = dr2;
            RadioButtonListPaymentMode.DataTextField = "PaymentModeName";
            RadioButtonListPaymentMode.DataValueField = "PaymentModeId";
            RadioButtonListPaymentMode.DataBind();
            dr2.Close();


            //while (dr.Read())
            //{
            //    City.Items.Add(dr["CityName"].ToString());
            //}
           
        }
    }
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        SqlConnection cn = new SqlConnection(@"Data Source=(localdb)\Projects;Initial Catalog=koko;Integrated Security=True;");
        cn.Open();
        SqlCommand cmdIns = new SqlCommand();
        cmdIns.Connection = cn;
        cmdIns.CommandText = "InsertUserMaster";
        cmdIns.CommandType = System.Data.CommandType.StoredProcedure;
        cmdIns.Parameters.AddWithValue("@UserName", TextUserName.Text);
        cmdIns.Parameters.AddWithValue("@UserPass", TextUserPass.Text);
        cmdIns.Parameters.AddWithValue("@EmailId", TextEmailId.Text);
        //cmdIns.Parameters.AddWithValue("@Address","pune");
        //cmdIns.Parameters.AddWithValue("@CityId",1);
        //cmdIns.Parameters.AddWithValue("@PaymentModeId",2);
        //cmdIns.Parameters.AddWithValue("@Gender","M");
        cmdIns.Parameters.AddWithValue("@Address",TextAddress.Value);
        cmdIns.Parameters.AddWithValue("@CityId",City.Text);
        cmdIns.Parameters.AddWithValue("@PaymentModeId",RadioButtonListPaymentMode.Text);
        cmdIns.Parameters.AddWithValue("@Gender", RadioButtonListGender.Text);
        cmdIns.ExecuteNonQuery();


        //SqlCommand cmdIns = new SqlCommand();
      
        foreach (ListItem li in CheckBoxListHobbies.Items)
        {
            if(li.Selected)
            {
                SqlCommand cmdIns1 = new SqlCommand();
                cmdIns1.Connection = cn;
                cmdIns1.CommandText = "InsertHobby";
                cmdIns1.CommandType = System.Data.CommandType.StoredProcedure;
                cmdIns1.Parameters.AddWithValue("@HobbyId", li.Value);
                cmdIns1.Parameters.AddWithValue("@UserName",TextUserName.Text);
                cmdIns1.ExecuteNonQuery();
            }
        }
        cn.Close();
    }
    protected void RadioButtonListGender_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
}