﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Login : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        HttpCookie obj2 = Request.Cookies["coockie"];
        if(!IsPostBack)
        {
            if (obj2 != null)
            {
                Response.Redirect("Home.aspx");
            }
        }   
    }
    protected void Button1_Click(object sender, EventArgs e)
    {

        SqlConnection cn = new SqlConnection(@"Data Source=(localdb)\Projects;Initial Catalog=koko;Integrated Security=True;");
        cn.Open();
        SqlCommand cmdIns = new SqlCommand();
        cmdIns.Connection = cn;
        cmdIns.CommandText = "select count(*) from UserMaster where UserName=@name";
        cmdIns.Parameters.AddWithValue("@name",UserName.Text);
        Object o=cmdIns.ExecuteScalar().ToString();

        if (o!=null)
        {
            if (CheckBox1.Checked)
            {
                HttpCookie obj = new HttpCookie("coockie");
                obj.Values["Username"] =UserName.Text;
                obj.Values["password"] = UserPass.Text;
                obj.Expires = DateTime.Now.AddDays(1);
                Response.Cookies.Add(obj);
                Response.Redirect("Home.aspx");
            }
            else
            {
                Session["koko"] = UserName.Text;
                Response.Redirect("Home.aspx");
            }
        }
        else
        {
            Response.Write("Error occure");
            Response.Redirect("Login.aspx");
        }    
        }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        Response.Redirect("Register.aspx");
    }
    protected void Username_TextChanged(object sender, EventArgs e)
    {

    }
}

  