﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Update : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        SqlConnection cn = new SqlConnection(@"Data Source=(localdb)\Projects;Initial Catalog=koko;Integrated Security=True;");
        cn.Open();

        SqlCommand cmdIns = new SqlCommand();
        cmdIns.Connection = cn;
       
        cmdIns.CommandText = "select * from CityMaster";
       
        SqlDataReader dr12 = cmdIns.ExecuteReader();
        City.DataSource = dr12;
        City.DataTextField = "CityName";
        City.DataValueField = "CityId";
        City.DataBind();
        dr12.Close();


        cmdIns.CommandText = "select * from HobbyMaster";
        SqlDataReader dr1 = cmdIns.ExecuteReader();
        CheckBoxListHobbies.DataSource = dr1;
        CheckBoxListHobbies.DataTextField = "HobbyName";
        CheckBoxListHobbies.DataValueField = "HobbyId";
        CheckBoxListHobbies.DataBind();
        dr1.Close();

        cmdIns.CommandText = "select * from PaymentModeMaster";
        SqlDataReader dr2 = cmdIns.ExecuteReader();
        RadioButtonListPaymentMode.DataSource = dr2;
        RadioButtonListPaymentMode.DataTextField = "PaymentModeName";
        RadioButtonListPaymentMode.DataValueField = "PaymentModeId";
        RadioButtonListPaymentMode.DataBind();
        dr2.Close();


        SqlCommand cmd = new SqlCommand();
        cmd.Connection = cn;

        cmd.CommandText = "select * from UserMaster where UserName='"+Session["koko"].ToString()+"'";

        SqlDataReader dr = cmd.ExecuteReader();
        while(dr.Read())
        {
            TextName.Text=dr["UserName"].ToString();
            TextEmail.Text=dr["EmailId"].ToString();
            TextAddress.InnerText = dr["Address"].ToString();
            RadioButtonListPaymentMode.SelectedValue = dr["PaymentModeId"].ToString();
            RadioGender.SelectedValue=dr["Gender"].ToString();
        }
        dr.Close();

        SqlCommand cmd1 = new SqlCommand();
        cmd1.Connection = cn;

        cmd1.CommandText = "select * from HobbyMaster where UserName='" + Session["koko"].ToString() + "'";

        SqlDataReader dr4 = cmd.ExecuteReader();
        while (dr4.Read())
        {
            if(CheckBoxListHobbies.SelectedValue.)
            {

            }
        }
        dr4.Close();
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        SqlConnection cn = new SqlConnection(@"Data Source=(localdb)\Projects;Initial Catalog=koko;Integrated Security=True;");
        cn.Open();
        SqlCommand cmdIns = new SqlCommand();
        cmdIns.Connection = cn;
        cmdIns.CommandText = "update UserMaster set UserName=@UserName,EmailId=@EmailId,Address=@Address,CityId=@CityId,PaymentModeId=@PaymentModeId,Gender=@Gender where UserName='"+Session["koko"].ToString()+"'";

        cmdIns.Parameters.AddWithValue("@UserName", TextName.Text);
        cmdIns.Parameters.AddWithValue("@EmailId", TextEmail.Text);
        cmdIns.Parameters.AddWithValue("@Address", TextAddress.Value);
        cmdIns.Parameters.AddWithValue("@CityId", City.Text);
        cmdIns.Parameters.AddWithValue("@PaymentModeId", RadioButtonListPaymentMode.Text);
        cmdIns.Parameters.AddWithValue("@Gender", RadioGender.Text);
        cmdIns.ExecuteNonQuery();


        //SqlCommand cmdIns = new SqlCommand();

        foreach (ListItem li in CheckBoxListHobbies.Items)
        {
            if (li.Selected)
            {
                SqlCommand cmdIns1 = new SqlCommand();
                cmdIns1.Connection = cn;
                cmdIns1.CommandText = "InsertHobby";
                cmdIns1.CommandType = System.Data.CommandType.StoredProcedure;
                cmdIns1.Parameters.AddWithValue("@HobbyId", li.Value);
                cmdIns1.Parameters.AddWithValue("@UserName", TextUserName.Text);
                cmdIns1.ExecuteNonQuery();
            }
        }
        cn.Close();
    }
}