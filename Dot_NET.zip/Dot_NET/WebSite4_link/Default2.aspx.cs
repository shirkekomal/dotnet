﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Default2 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //REsponce.Redirect
        //Label1.Text = Request.Form["first"]+" "+Request.Form["last"];

        //QueryString
        //Label1.Text = Request.QueryString["FirstName"] + " " + Request.QueryString["LastName"];


        //HttpCookie obj = Request.Cookies["komal"];
        //if (obj != null)
        //{
        //    Label1.Text = obj.Value;
        //    Label1.Text = obj.Values["First"] + " " + obj.Values["Last"];
        //}
        //else
        //{
        //    Label1.Text = "Cookie Missing ";
        //}


        //session 
      //  Label1.Text ="WelCome  "+ Session["First"].ToString()+"   "+Session["Last"].ToString();


    //PostBack URL

    //Label1.Text=Request.Form["First"]+" "+Request.Form["last"];

        //Code for postback url with previous page type

       //TextBox First = (TextBox)PreviousPage.FindControl("First");
       //Label1.Text = First.Text;


        ////Code for postback url with previous page type with property on first page

      // TextBox FirstName = PreviousPage.FirstName;
      // Label1.Text = FirstName.Text;
       //if (PreviousPage.FirstName != null)
       //{
       //    Label1.Text = PreviousPage.FirstName.Text;
       //}
       //else
       //{
       //    //Response.Write("Null Value");
       //    Label1.Text = "Null Value";
       
       //}

        // to take Count
        if(!IsPostBack)
        {
            ViewState["Count"] = 0;

        }
        else
        {
            ViewState["Count"] =((int) ViewState["Count"]) + 1;

            Label2.Text = ViewState["Count"].ToString();
        }

    }
    protected void Button1_Click(object sender, EventArgs e)
    {

    }
}