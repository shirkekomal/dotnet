﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void TextBox1_TextChanged(object sender, EventArgs e)
    {
        
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        //Server.Transfer("Default2.aspx");
    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
       //Response.Redirect("default2.aspx");

       //QueryString
       //Response.Redirect("Default2.aspx?FirstName="+First.Text+"&LastName="+Last.Text);

        
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        HttpCookie obj = new HttpCookie("komal");
        //obj.Value = First.Text;
        obj.Values["First"] = First.Text;
        obj.Values["Last"] = Last.Text;
        obj.Expires = DateTime.Now.AddHours(2);
        Response.Cookies.Add(obj);
        Response.Redirect("Default2.aspx");
    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        Session["First"] = First.Text;
        Session["Last"] = Last.Text;
        Response.Redirect("Default2.aspx");
    }
    protected void LinkButton2_Click(object sender, EventArgs e)
    {

    }

    public TextBox FirstName
    {
        get { return First; }
    }
}