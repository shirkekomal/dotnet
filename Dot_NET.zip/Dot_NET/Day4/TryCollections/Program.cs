﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TryCollections
{
    class Program
    {
        static void Main()
        {
            ArrayList o = new ArrayList();
            o.Add(10);
            o.Add("aaa");
            o.Add("bbb");
            o.Add("ccc");
            o.RemoveAt(0);
            o.Remove("aaa");

            for (int i = 0; i < o.Count; i++)
                Console.WriteLine(o[i]);
            foreach (object obj in o)
                Console.WriteLine(obj);
            foreach (var item in o)
                Console.WriteLine(item);
            Console.ReadLine();
        }
    }
}
