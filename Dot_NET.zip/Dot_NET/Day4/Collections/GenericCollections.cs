﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QueueType
{
    class Generic
    {
        static void Main15()
        {
            Queue<int> Obj = new Queue<int>();

            Obj.Enqueue(10);
            Obj.Enqueue(20);
            Obj.Enqueue(30);
            Obj.Enqueue(40);
            Console.WriteLine(Obj.Peek());

            Console.WriteLine("----------------------");
            Console.WriteLine(Obj.Dequeue());
            Console.WriteLine(Obj.Dequeue());
            Console.WriteLine(Obj.Dequeue());
            Console.WriteLine(Obj.Dequeue());

            Queue<string> Obj1 = new Queue<string>();
            Obj1.Enqueue("komal");
            Obj1.Enqueue("nikam");
            Obj1.Enqueue("Shirke");
            Obj1.Enqueue("C-DAC");

            Console.WriteLine("----------------------");
            Console.WriteLine(Obj1.Peek());

            Console.WriteLine("----------------------");
            Console.WriteLine(Obj1.Dequeue());
            Console.WriteLine(Obj1.Dequeue());
            Console.WriteLine(Obj1.Dequeue());
            Console.WriteLine(Obj1.Dequeue());

        }
    }
}

namespace StackType
{
    class Generic
    {
        static void Main19()
        {
            Stack<int> Obj = new Stack<int>();

            Obj.Push(10);
            Obj.Push(20);
            Obj.Push(30);
            Obj.Push(40);
            Console.WriteLine(Obj.Peek());

            Console.WriteLine("----------------------");
            Console.WriteLine(Obj.Pop());
            Console.WriteLine(Obj.Pop());
            Console.WriteLine(Obj.Pop());
            Console.WriteLine(Obj.Pop());

            Stack<string> Obj1 = new Stack<string>();
            Obj1.Push("komal");
            Obj1.Push("nikam");
            Obj1.Push("Shirke");
            Obj1.Push("C-DAC");

            Console.WriteLine("----------------------");
            Console.WriteLine(Obj1.Peek());

            Console.WriteLine("----------------------");
            Console.WriteLine(Obj1.Pop());
            Console.WriteLine(Obj1.Pop());
            Console.WriteLine(Obj1.Pop());
            Console.WriteLine(Obj1.Pop());

        }
    }
}

namespace SortedListType
{ 

    class SortesLists
    {
        static void Main18()
        {
            SortedList<int, string> ObjList = new SortedList<int, string>();
            ObjList.Add(1, "Komal");
            ObjList[2] = "Shirke";

            foreach(KeyValuePair<int,string> kvp in ObjList)
            {
                Console.WriteLine(kvp.Key+"   "+kvp.Value);
            }
            ObjList.Remove(1);

        }

    }
}

namespace UserDefinedListType
{
    class Generic
    {
        static void Main17()
        {
           List<Employee> Obj=new List<Employee>();
           Obj.Add(new Employee { EmpNo = 1, EmpName = "Komal" });
           Obj.Add(new Employee { EmpNo =2, EmpName = "kk" });
            Obj.Add(new Employee { EmpNo = 3, EmpName = "koko" });
            

            foreach(Employee e in Obj)
            {
                Console.WriteLine("empName-->>" + e.EmpName + "  " + "EmpNo-->>" + e.EmpNo);
            }

            Console.WriteLine("---------------------------");

            Employees e1 = new Employees();
            e1.Add(new Employee { EmpNo = 1, EmpName = "ABC" });
            e1.Add(new Employee { EmpNo = 2, EmpName = "XYZ" });
            e1.Add(new Employee { EmpNo = 3, EmpName = "PQR" });


            foreach (var e11 in e1)
            {
                Console.WriteLine("empName -->>" + e11.EmpName + "  " + "EmpNo -->>" + e11.EmpNo);
            }


        }
    }

    class Employee
    {
        private int empNo;

        public int EmpNo
        {
            get { return empNo; }
            set { empNo = value; }
        }

        private string empName;

        public string EmpName
        {
            get { return empName; }
            set { empName = value; }
        }
    }

    class Employees:List<Employee>
    {
        
    }
}



