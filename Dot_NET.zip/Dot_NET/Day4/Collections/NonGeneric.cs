﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HashTable
{
    class NonGeneric
    {
        static void Main10()
        {
            Hashtable obj = new Hashtable();
            obj.Add(0, 10);
            obj.Add(1, 20);
            obj[2] = "Komal";
            obj[2] = "KOKO";

            foreach(DictionaryEntry ObjEnty in obj)
            {
                Console.WriteLine(ObjEnty.Key+"   "+ObjEnty.Value);
            }

        }
    }
}


namespace SortedLists
{
    class NonGeneric
    {
        static void Main11()
        {
            SortedList obj = new SortedList();
            obj.Add(0, 10);
            obj.Add(1, 20);
            obj[2] = "Komal";
            obj[2] = "KOKO";

            foreach (DictionaryEntry ObjEnty in obj)
            {
                Console.WriteLine(ObjEnty.Key + "   " + ObjEnty.Value);
            }

        }
    }
}

namespace StackType
{
    class NonGeneric
    {
        static void Main12()
        {
            Stack Obj = new Stack();

            Obj.Push(10);
            Obj.Push(20);
            Obj.Push(30);
            Obj.Push(40);
            Console.WriteLine(Obj.Peek());

            Console.WriteLine("----------------------");
            Console.WriteLine(Obj.Pop());
            Console.WriteLine(Obj.Pop());
            Console.WriteLine(Obj.Pop());
            Console.WriteLine(Obj.Pop());

        }
    }
}


namespace QueueType
{
    class NonGeneric
    {
        static void Main14()
        {
            Queue Obj = new Queue();

            Obj.Enqueue(10);
            Obj.Enqueue(20);
            Obj.Enqueue(30);
            Obj.Enqueue(40);
            Console.WriteLine(Obj.Peek());

            Console.WriteLine("----------------------");
            Console.WriteLine(Obj.Dequeue());
            Console.WriteLine(Obj.Dequeue());
            Console.WriteLine(Obj.Dequeue());
            Console.WriteLine(Obj.Dequeue());

        }
    }
}

