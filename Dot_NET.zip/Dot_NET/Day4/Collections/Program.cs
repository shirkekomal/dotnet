﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Collections
{
    class Program
    {
        static void Main8(string[] args)
        {

            ArrayList a = new ArrayList();
            a.Add(10);
            a.Add("Komal");
            a.Add(20);
            a.Add(20.2);
            a.Add('K');

            for (int i = 0; i < a.Count; i++)
            {
                Console.WriteLine(a[i]);
            }

            Console.WriteLine("------------------");
            
            a.Remove(10);
            foreach(Object obj in a )
            {
                Console.WriteLine(obj);
            }
            
            Console.WriteLine("------------------");
            a.RemoveAt(0);
            foreach (var item in a)
            {
                Console.WriteLine(item);
            }

            Console.WriteLine("------------------");
            a.Reverse();
            for (int i = 0; i < a.Count; i++)
            {
                Console.WriteLine(a[i]);
            }

            Console.WriteLine("------------------");
            a.RemoveRange(0,1);
            for (int i = 0; i < a.Count; i++)
            {
                Console.WriteLine(a[i]);
            }
        }
    }
}
