﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace selectArray
{
    class Program
    {
        static void Main1(string[] args)
        {
            int[] num = { 1, 2, 3, 4, 5, 6, 7 };

            var nn=from n in num select n+1;

            Console.WriteLine("Numbers");
            foreach(var i in nn)
            {
                Console.WriteLine(i);
            }
            Console.ReadLine();
        }
    }
}

namespace selectListEmp
{
    class Program1
    {
        static void Main(string[] args)
        {
            List<Employee> l;
            l = new List<Employee>()
            {
                new Employee{EmpNo=1,EmpName="komal",Basic=12000,DeptNo=1},
                new Employee{EmpNo=2,EmpName="komal2",Basic=22000,DeptNo=1},
                new Employee{EmpNo=3,EmpName="komal3",Basic=32000,DeptNo=2},
                new Employee{EmpNo=4,EmpName="komal4",Basic=20000,DeptNo=1},
                new Employee{EmpNo=5,EmpName="komal5",Basic=25000,DeptNo=2}
            };

            List<Dept> d = new List<Dept> { 
                new Dept{DeptNo=1,DeptName="ËXTC"},
                new Dept{DeptNo=2,DeptName="CS"}
            };

            //var emps = from emp in l select emp;

            //var emps = from emp in l select emp.EmpName;

            //var emps = from emp in l select new { emp.EmpName, emp.Basic};

            //var emps = from emp in l where emp.EmpNo>5 select emp;

//            var emps = from emp in l where emp.EmpNo > 1 && emp.EmpNo < 4 select emp;

            //var emps = from emp in l where emp.Basic > 20000 || emp.EmpNo < 4 select emp;

            //var emps = from emp in l orderby emp.EmpName descending, emp.EmpNo descending select emp;

            //var emps = from emp in l join dept in d on emp.DeptNo equals dept.DeptNo select new { emp.EmpName, dept.DeptName };
            
            //var emps = from emp in l join dept in d on emp.DeptNo equals dept.DeptNo where emp.Basic<20000 select new { emp.EmpName, dept.DeptName };

            //var emps = from emp in l group emp by emp.DeptNo into komal select komal;
            var emps = from emp in l group emp by emp.DeptNo into Empl where Empl.Count() > 1 select new { Empl.Key,Empl.Count()}; 

            foreach (var item in emps)
            {
                Console.WriteLine(item.Key);
                foreach (var item1 in item)
                {
                    Console.WriteLine(item1.EmpName);
                }
            }
            Console.ReadLine();
        }
    }
    public class Employee
    {
        public int EmpNo;
        public String EmpName;
        public decimal Basic;
        public int DeptNo;

        public override string ToString()
        {
            return EmpNo+" "+EmpName+""+Basic+" "+DeptNo;
        }
    }
    public class Dept
    {
        public int DeptNo;

        public String DeptName;

        public override string ToString()
        {
            return DeptNo + "   " + DeptName;
        }
    }

}

namespace FunctionLINQ
{
    class Program2
    {
        static void Main3(string[] args)
        {
            List<Employee> l;
            l = new List<Employee>()
            {
                new Employee{EmpNo=1,EmpName="komal",Basic=12000,DeptNo=1},
                new Employee{EmpNo=2,EmpName="komal2",Basic=22000,DeptNo=1},
                new Employee{EmpNo=3,EmpName="komal3",Basic=32000,DeptNo=2},
                new Employee{EmpNo=4,EmpName="komal4",Basic=20000,DeptNo=1},
                new Employee{EmpNo=5,EmpName="komal5",Basic=25000,DeptNo=2}
            };

            List<Dept> d = new List<Dept> { 
                new Dept{DeptNo=1,DeptName="ËXTC"},
                new Dept{DeptNo=2,DeptName="CS"}
            };

            //var emps = l.Select(emp=>emp.Basic);
            //var emps = l.Select(emp => emp);


            //var emps = from emp in l select new { emp.EmpName, emp.Basic};
              //var emps=l.Select(emp=>new {emp.EmpName,emp.Basic});

            //var emps = from emp in l where emp.EmpNo>5 select emp;
                //var emps = l.Select(emp => emp).Where(emp=>emp.Basic<20000);

            //  var emps = from emp in l where emp.EmpNo > 1 && emp.EmpNo < 4 select emp;
                //var emps = l.Select(emp => emp).Where(emp => emp.EmpNo > 1).Where(emp => emp.EmpNo < 4);
                //var emps = l.Select(emp => emp).Where(emp => emp.EmpNo > 1 && emp.EmpNo < 4);

            //var emps = from emp in l where emp.Basic > 20000 || emp.EmpNo < 4 select emp;
               //var emps = l.Select(emp => emp).Where(emp => emp.EmpNo == 1 || emp.EmpNo == 4);

            //var emps = from emp in l orderby emp.EmpName descending, emp.EmpNo descending select emp;
            //var emps = l.Select(emp => emp).OrderBy(emp=>emp.EmpName);
            //var emps = l.Select(emp => emp).OrderByDescending(emp => emp.EmpName);

            //var emps = from emp in l join dept in d on emp.DeptNo equals dept.DeptNo select new { emp.EmpName, dept.DeptName };

            //var emps = l.Join(d, (emp => emp.DeptNo), (dept => dept.DeptNo), (emp, dept) => new{emp.EmpName,dept.DeptName});
            
            //var emps = from emp in l join dept in d on emp.DeptNo equals dept.DeptNo where emp.Basic<20000 select new { emp.EmpName, dept.DeptName };

             var emps = l.Join(d, emp => emp.DeptNo, dept => dept.DeptNo, (emp, dept) => new { emp.EmpName,emp.Basic, dept.DeptName }).Where(emp=> emp.Basic>20000);
          

            foreach (var item in emps)
            {
                Console.WriteLine(item);
            }

            Console.ReadLine();
        }


    }

    public class Employee
    {
        public int EmpNo;
        public String EmpName;
        public decimal Basic;
        public int DeptNo;

        public override string ToString()
        {
            return EmpNo + " " + EmpName + " " + Basic + " " + DeptNo;
        }
    }
    public class Dept
    {
        public int DeptNo;

        public String DeptName;

        public override string ToString()
        {
            return DeptNo + "   " + DeptName;
        }
    }

}
