﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ImplicitVariables
{
    //implicit variables
    class Program
    {
    
        static void Main1()
        {
            int i = 0;
            var i2 ="aaa";
            //var i3;
            //i2 = "aaa";
            Console.WriteLine(i.GetType());
            Console.WriteLine(i2.GetType());

            Console.ReadLine();

        }
    }

}
namespace ExtensionMethods
{
    class Program
    {
        //- Extension methods must be declared inside a static class
        //- Mark a method as an extension method by using the --this-- keyword as a modifier 
        //           on the first parameter of the method
        //- Every extension method can be called either from the object or statically via the defining static class
        static void Main2()
        {
            string s = "aa";
            int i = 0;
            int j = 10;
            i.Print();

            ExtensionMethodsClass.Print(i);

            Class1 o = new Class1();
            o.Show();

            Console.ReadLine();
        }
    }
    static class ExtensionMethodsClass
    {
        public static void Print(this int i)
        {
            Console.WriteLine(i);
        }
        //extension method defined for base class is also available for the derived class
        public static void Display(this object i)
        {
            Console.WriteLine(i.ToString());
        } 
        //extension method defined for interface is available 
        //for the classes that implement that interface
        public static void Show(this IDbFunctions i)
        {
            Console.WriteLine(i.ToString());
        }
    }
    public interface IDbFunctions
    {
        void Insert();
        void Update();
    }
    public class Class1 : IDbFunctions
    {

        public void Insert()
        {
            throw new NotImplementedException();
        }

        public void Update()
        {
            throw new NotImplementedException();
        }
    }

}
namespace AnonymousTypes
{
    class Program
    {
        static void Main3()
        {
            //anonymous type is a class that does not have a name
            //create an anonymous type by using var and specifying properties of the type

            //class1 o = new class1();
            var obj1 = new { EmpNo = 1, Name = "abc", DeptNo = 20 };
            var obj2 = new { EmpNo = 2, Name = "pqr", DeptNo = 30 };
            var obj3 = new { EmpNo = 2, Name = "pqr" };
            Console.WriteLine(obj1.Name);
            Console.ReadLine();
        }
    }

}

namespace PartialClasses
{
    class Program
    {
        static void Main2()
        {
            Class1 o = new Class1();
            Console.ReadLine();
        }
    }
    public partial class Class1
    {
        public int i;
    }
}

namespace PartialMethods
{
    class Program
    {
        static void Main1()
        {
            Class1 obj = new Class1();
            Console.WriteLine(obj.Check());
            Console.ReadLine();
        }
    }
    //Partial methods can only be defined within a partial class.
    //Partial methods must return void.
    //Partial methods can be static or instance level.
    //Partial methods cannnot have out params
    //Partial methods are always implicitly private.
    public partial class Class1
    {
        private bool isValid = true;
        partial void Validate();
        public bool Check()
        {
            Validate();
            return isValid;
        }
    }
    public partial class Class1
    {
        partial void Validate()
        {
            //perform some validation code here
            isValid = false;
        }
    }
}

namespace ObjectInitializers
{
    public class MainClass
    {
        public static void Main()
        {
            Class1 o = new Class1();
            o.X = 100;
            o.Y = 200;
            Console.WriteLine(o.X);
            Console.WriteLine(o.Y);

            Class1 o1 = new Class1() { X = 10, Y = 20 };
            Class1 o2 = new Class1 { X = 10, Y = 20 };

            Class1 o3 = new Class1(20) { X = 10};
            Console.ReadLine();
        }
    }

    public class Class1
    {
        public int X, Y;
        public Class1(int y)
        {
            Y = y;
        }
        public Class1()
        {
            Y = 1;
            X = 2;
        }
    }
}
