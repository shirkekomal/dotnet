﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LambdaExpression
{
    class Program
    {
        static void Main1(string[] args)
        {
            Func<int, int, int> obj = delegate(int a, int b)
        {
            return a + b;
        };
            obj = delegate(int a, int b)
            {
                return a - b;
            };
            Console.WriteLine(obj(10, 20));
            Console.WriteLine(obj(130, 20));
            Console.ReadLine();
        }
    }
}
namespace LambdaExpression1
{
    class Program
    {
        static void Main3(string[] args)
        {
            Func<int, int, int> obj = new Func<int, int, int>(Add);
            Console.WriteLine("Addiotion"+obj(10, 20));


            Func<int, int, int> obj1 = (a, b) => a + b;
            Console.WriteLine("Addition" + obj1(10, 20));

            Func<int,int> obj2 = i => i * 2;
            Console.WriteLine("Double-->>" + obj2(10));

            Func<int, bool> obj3 = i => i % 2 == 0;
            Console.WriteLine("Even or Odd-->>" + obj3(10));

            Predicate<int> obj4 = i => i % 2 == 0;
            Console.WriteLine("Even or Odd-->>" + obj4(2));

            Employee emp=new Employee();
            emp.Basic = 20000;
            Predicate<Employee> obj5 = e => e.Basic > 10000;
            Console.WriteLine("salary-->>"+obj5(emp));

            Func<int, String, String> obj6 = (a, Name) => "komal";
            Console.WriteLine("Name-->"+obj6(10,"komal"));

            Func<int,int,int> obj7=(a,b)=>
            {
                if (a > b)
                    return a;
                else
                    return b;
            };

            Console.WriteLine("Geater or less-->>"+obj7(10, 20));
            
        }

        static int Add(int a,int b)
        {
            return a+b;
        }

        public class Employee
        {
            private float basic;

            public float Basic
            {
                get { return basic; }
                set { basic = value; }
            }
        }


      }
}