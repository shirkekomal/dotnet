﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ImplicitVariable
{
   
    class ExtentionMethod
    {
       static void Main5()
        {
            int i = 0;
            i.Print();
            ExtentionClass.Print(10);
            int j = 20;
            j.Print();
            var i1 = "komal";
            var j1 = "Nikam";
            ExtentionClass.Display(i1,10);
            j1.Display(10);
            Class5 c = new Class5();
            c.Show();
       

           // j.Display("komal");
            // i1.Display();
            // j1.Display();
            
        }
    }

    static class ExtentionClass
    {
        public static void Print(this int i)
        {
            Console.WriteLine("inside Print"+i);
        }

        public static void Display(this Object i, int j)
        {
            Console.WriteLine("Display-->>"+i.ToString()+" "+"value"+j);
        }

        public static void Show(this IDbFunctions i)
        {
            Console.WriteLine(i.ToString());
        }
    }
    public interface IDbFunctions
    {
        void Insert();
        void Update();
    }

    public class Class5 : IDbFunctions
    {

        public void Insert()
        {
            throw new NotImplementedException();
        }

        public void Update()
        {
            throw new NotImplementedException();
        }
    }
}
