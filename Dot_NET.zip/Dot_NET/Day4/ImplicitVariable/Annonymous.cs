﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AnnonymousType
{
    class Annonymous
    {

        static void Main6()
        {
            var obj = new { EmpName = "Komal", EmpSal = 12000 };
            Console.WriteLine("Empname-- "+obj.EmpName+"\n"+"EmpSal-- "+obj.EmpSal);
        }
    }
}
namespace PartialClass
{
    public partial class class1
    {
        public int i;

        }
    public partial class class1
    {
        public int j;

    }

    class Annonymous1
    {
        static void Main7()
        {
            class1 c = new class1();
            c.i = 20;
            Console.WriteLine( "i"+ c.i);
            c.j = 10;
            Console.WriteLine("j" + c.j);
        }

    }


}

namespace PartialMethod
{
    public partial class class1
    {
        private bool isValid = true;
        partial void valid();

        public bool Check()
        {
            valid();
            return isValid;
        }
    }
    public partial class class1
    {
        partial void valid()
        {
            isValid = false;
        
        }

    }

    class PartialMethodDemo
    {
        static void Main7()
        {
            class1 c = new class1();
            Console.WriteLine( c.Check());

        }

    }


}


namespace objectInitialization
{

    public class MainClass
    {

        static void Main()
        {
            Class1 c = new Class1();
            c.X = 100;
            c.Y = 200;
            Console.WriteLine("X "+c.X);
            Console.WriteLine("Y " + c.Y);


            Class1 c1 = new Class1() { X = 10, Y = 20 };
            
            Console.WriteLine("X " + c1.X);
            Console.WriteLine("Y " +c1.Y);

            Class1 c2 = new Class1 { X = 1, Y = 2 };

            Console.WriteLine("X " + c2.X);
            Console.WriteLine("Y " + c2.Y);

        }


    }
    public class Class1
    {
        public int X, Y;
        public Class1(int y)
        {
            Y = y;
        }
        public Class1()
        {
            Y = 1;
            X = 2;
        }
    }
}