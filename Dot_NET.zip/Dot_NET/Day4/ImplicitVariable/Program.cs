﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ImplicitVariable
{
    class Program
    {
        static void Main1(string[] args)
        {
            int i = 0;
            var j = "kom";
            var k =0;
          
            Console.WriteLine("i"+i.GetType());
            Console.WriteLine("j" + j.GetType());
            Console.WriteLine("k" + k.GetType());

        }

    }
}
