﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IDisposableExample
{
    public class Program
    {
        static void Main()
        {
            Class1 o;
            using (o = new Class1())
            {
                o.Display();
                //o.Dispose();
            }
            o.Display();
            

            Console.ReadLine();
        }

    }
    public class Class1 :IDisposable
    {
        private bool isDisposed;
        public void Display()
        {
            CheckForDisposed();
            Console.WriteLine("Disp");
        }
        public void Dispose()
        {
            //use this method instead of writing code in a destructor
            //cleanup code goes here
            Console.WriteLine("dispose code");
            isDisposed = true;
        }
        private void CheckForDisposed()
        {
            if (isDisposed)
                throw new ObjectDisposedException("Class1");
        }
    }
}
