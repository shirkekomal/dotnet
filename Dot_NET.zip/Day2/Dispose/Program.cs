﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dispose
{
    public class Demo:IDisposable
    {
        public void Display()
        {
            Console.WriteLine("Display method ");
        }

        public void Dispose()
        {
            Console.WriteLine("Dispose Method calls");
        }
    }

    class Program
    {
        static void Main1(string[] args)
        {
            Demo d = new Demo();
            using (d = new Demo()) // used to despose the object after use
            {
                d.Display();
              //  d.Dispose();
            }
            d.Display();
        }
    }
}
