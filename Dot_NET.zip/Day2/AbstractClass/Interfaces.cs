﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractClass
{
    public interface InterFaceDemo
    {
        void Insert();
        void Update();
        void Delete();
    }

    class Class1:InterFaceDemo
    {

        public void Insert()
        {
            Console.WriteLine("Insert Method in Class1");
        }

        public void Update()
        {
            Console.WriteLine("Update Method in Class1"); 
        }

        public void Delete()
        {
            Console.WriteLine("Delete Method in Class1");
        }
    }

    class Interfaces
    {
        static void Main2(string[] args)
        {
            Class1 d = new Class1();
            d.Delete();
            d.Insert();
            d.Update();

            Console.WriteLine("<<--------------------------------->>");
            InterFaceDemo id;
            id = d;
            id.Delete();
            id.Insert();
            id.Update();
            Console.WriteLine("<<--------------------------------->>");
            ((InterFaceDemo)d).Insert();
            ((InterFaceDemo)d).Update();
            ((InterFaceDemo)d).Delete();
        }
    }

}
