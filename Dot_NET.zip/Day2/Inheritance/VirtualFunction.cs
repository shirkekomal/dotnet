﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Inheritance
{
    public class Base11
    {
        public Base11()
        {
            Console.WriteLine("Base11 Const");
        }

        public void Display11()
        {
            Console.WriteLine("Display of Base11");
        }
        public virtual void Display22()
        {
            Console.WriteLine("Display of Base11");
        }

    }
    public class Derived11 : Base11
    {
        public Derived11()
        {
            Console.WriteLine("Derived11 Const");
        }

        public new void Display11()
        {
            Console.WriteLine(" Derived Display11");
        }
        public override void Display22()
        {
            Console.WriteLine("Derived Display22");
        }

    }

    public class Derived22 : Derived11
    {
        public Derived22()
        {
            Console.WriteLine("Derived22 Const");
        }

        public new void Display11()
        {
            Console.WriteLine(" Derived Derived22");
        }
        public sealed override void Display22()
        {
            Console.WriteLine("Derived Derived22");
        }

    }

    #region sealed
    //public sealed class SealDemo
    //{
    //    public int i;
    //}
    //public class S1:SealDemo
    //{
        
    //}


    //public class Derived33 : Derived22
    //{
    //    public Derived33()
    //    {
    //        Console.WriteLine("Derived22 Const");
    //    }

    //    public new void Display11()
    //    {
    //        Console.WriteLine(" Derived33 Display11");
    //    }
    //    public sealed override void Display22()
    //    {
    //        Console.WriteLine("Derived33 Display22");
    //    }

    //}         

    #endregion
    class VirtualFunction
    {

        static void Main4()
        {
            Base11 b; 
            //b= new Base11();
            //b.Display11();
            //b.Display22();

            //Console.WriteLine("---------------------");

            //Derived11 d = new Derived11();
            //d.Display11();
            //d.Display22();

            Console.WriteLine("---------------------");
            b=new Base11();
            Base11 b2 = new Derived11();
            Base11 b3 = new Derived22();
            //b.Display11();
            //b.Display22();
            callDisplay3(b);
            callDisplay3(b2);
            callDisplay3(b3);
        }
        static void callDisplay3(Base11 bb)
        {
            bb.Display22();
        }

    }
}
