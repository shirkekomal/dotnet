﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Inheritance
{

    public class Parent
    {
        public void Display()
        {
            Console.WriteLine("Parent Display()");
        }
    }


    public class Child:Parent
    {
        public void Display(int i)
        {
            Console.WriteLine("Child Display "+ i);
        }

    }
    class Function_overloading
    {
        static void Main2()
        {
            Child c = new Child();
            c.Display(10);
            c.Display();

            Parent p = new Parent();
            p.Display();

        }
    }
}
