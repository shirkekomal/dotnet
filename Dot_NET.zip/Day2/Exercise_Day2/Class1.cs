﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Excersise_Day1
{
    class Program
    {
        private String name;
        public String Name
        {
            get { return name; }
            set
            {
                if (value.Length > 0)
                {
                    name = value;
                    Console.WriteLine("Name -->> " + name);
                }
                else
                    Console.WriteLine("String Cannot Be blank");
            }
        }
        private int empNo;

        public int EmpNo
        {
            get { return empNo; }
            set
            {
                if (value > 0)
                {
                    empNo = value;
                    Console.WriteLine("empNo -->> " + empNo);
                }
                else
                    Console.WriteLine("Employee no cannot be 0");
            }
        }
        private short deptNo;

        public short DeptNo
        {
            get { return deptNo; }
            set
            {
                if (value > 0)
                {
                    deptNo = value;
                    Console.WriteLine("deptNo -->> " + deptNo);
                }
                else
                    Console.WriteLine("Dept no cannot be blanck");
            }
        }
        private decimal basic;

        public decimal Basic
        {
            get { return basic; }
            set
            {
                if (value > 2000 && value < 10000)
                {
                    basic = value;
                    Console.WriteLine("Basic -->> " + basic);
                }
                else
                    Console.WriteLine("Enter Value between 2000 to 10000");
            }
        }

        public Program(String name, int empNo = 0, decimal basic = 1.1m, short deptNo = 0)
        {
            Name = name;
            EmpNo = empNo;
            DeptNo = deptNo;
            Basic = basic;
        }

        //public Program(String name, int empNo,decimal basic)
        //{
        //    Name = name;
        //    EmpNo = empNo;
        //    Basic = basic;
        //}


        //public Program(String name, int empNo)
        //{
        //    Name = name;
        //    EmpNo = empNo;
        //}

        //public Program(String name)
        //{
        //    Name = name;
        //}


        public decimal getNetSal(decimal hra = 0, decimal da = 0, decimal ta = 0)
        {
            decimal temp = da + ta + hra + basic;
            return temp;
        }


        static void Main1(string[] args)
        {
            Program p = new Program("komal", 1, 3111.5m, 1);
            Console.WriteLine("Net Salary=" + (p.getNetSal(1200.5m, 1300.5m, 2400.5m)));
            Console.WriteLine("--------------------------------------------------");
            Program p1 = new Program("kunal", 2, 2292.12m);
            //Console.WriteLine("Net Salary=" + (p1.getNetSal(1200.5m, 1300.5m, 2400.5m)));
            Console.WriteLine("--------------------------------------------------");
            Program p2 = new Program("sachin", 3);
            //Console.WriteLine("Net Salary=" + (p2.getNetSal(1200.5m, 1300.5m, 2400.5m)));
            Console.WriteLine("--------------------------------------------------");
            Program p3 = new Program("abc");
            //Console.WriteLine("Net Salary=" + (p3.getNetSal(1200.5m, 1300.5m, 2400.5m)));
            Console.ReadLine();
        }
    }
}

