﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise_Day2
{

    public abstract class  Employee1
    {
        private String name;
        public String Name
        {
            get { return name; }
            set
            {
                if (value.Length > 0)
                {
                    name = value;
                    Console.WriteLine("Name -->> " + name);
                }
                else
                    Console.WriteLine("String Cannot Be blank");
            }
        }
        private int empNo;

        public int EmpNo
        {
            get { return empNo; }
            set
            {
                if (value > 0)
                {
                    empNo = value;
                    Console.WriteLine("empNo -->> " + empNo);
                }
                else
                    Console.WriteLine("Employee no cannot be 0");
            }
        }
        private short deptNo;

        public short DeptNo
        {
            get { return deptNo; }
            set
            {
                if (value > 0)
                {
                    deptNo = value;
                    Console.WriteLine("deptNo -->> " + deptNo);
                }
                else
                    Console.WriteLine("Dept no cannot be blanck");
            }
        }

        protected decimal basic;
        public abstract decimal Basic
        {
            get;
            set;
        }

        
        public Employee1(String name, int empNo = 0, decimal basic = 1.1m, short deptNo = 0)
        {
            Name = name;
            EmpNo = empNo;
            DeptNo = deptNo;
            Basic = basic;
        }


        public abstract decimal getNetSal();
        

    }

    public class Manager : Employee1
    {
       
       public override decimal Basic
       {
           get
           {
               return basic;
           }
           set
           {
               basic = value;
               Console.WriteLine("Basic Salary-->>"+basic);
           }
       }

        private String designation;

        public String Designation
        {
            get
            { 
                return designation;
            }
            set 
            {
                designation = value;
                Console.WriteLine("Designation-->>" + designation);
            }
        } 

        public Manager(String empName,int empNo,decimal basic,short deptNo,String desgn):base (empName,empNo,basic,deptNo)
        {
          Designation=desgn;
        }

        public override decimal getNetSal()
        {
            return Basic;
        }
    }


    public class Employee
    {

        static void Main(string[] args)
        {
            Manager m=new  Manager("komal",1,10000m,10,"engg");
        }
    }
}

