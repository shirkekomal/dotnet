﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //MessageBox.Show(listBox1.Text);
            //MessageBox.Show(listBox1.SelectedIndex.ToString());
            //MessageBox.Show(listBox1.Items.Count.ToString());
            //MessageBox.Show(listBox1.SelectedItem.ToString());

            //for SelectionMode = Multi...
            foreach (var item in listBox1.SelectedItems)
            {
                MessageBox.Show(item.ToString());
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            listBox1.Items.Add("Karun");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            //listBox1.Items.Remove(listBox1.SelectedItem);
            //listBox1.Items.RemoveAt(listBox1.SelectedIndex);

        }
    }
}
