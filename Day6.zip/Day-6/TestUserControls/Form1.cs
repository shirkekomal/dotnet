﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TestUserControls
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            myListBoxes1.listBox1.Items.Add("a");
            myListBoxes1.listBox1.Items.Add("b");
            myListBoxes1.listBox1.Items.Add("c");

        }
    }
}
