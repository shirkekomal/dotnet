﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //if(base.IsPostBack)
        //if(IsPostBack)
        //if(this.Page.IsPostBack)
        //if(Page.IsPostBack)
        //if(base.Page.IsPostBack)
        //if (this.IsPostBack == false)

        if (!IsPostBack)
            Label1.Text = "Page loaded for the first time";
        else
            Label1.Text = "Page loaded due to a PostBack";

    }
    protected void btnShow_Click(object sender, EventArgs e)
    {
        lblMessage.Text = "Hello World";
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        //server controls
        txtFullName.Text = txtFirstName.Text + " " + txtLastName.Text;
        txtFullName.Text = Request.Form["txtFirstName"] + " " + Request.Form["txtLastName"];
        
        //html controls
        txtFullName.Text = Request.Form["Text1"] + " " + Request.Form["Text2"]; ;

        //html controls with runat="server"
        txtFullName.Text = Text3.Value + Text4.Value;
        txtFullName.Text = Request.Form["Text3"] + " " + Request.Form["Text4"]; ;
    }
}