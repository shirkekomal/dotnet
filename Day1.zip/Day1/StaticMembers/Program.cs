﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StaticMembers
{
    class Program
    {
        static void Main()
        {
            //Class1.static_a = 100;
            Console.WriteLine(Class1.static_a);

            Class1 o = new Class1();
            o.a = 10;

            o.Display();

            //Class1.static_Display();

            Class1.static_Prop1 = 123;

            Console.ReadLine();
        }
    }
    public class Class1
    {
        //static variables
        public int a;
        //single copy for the class
        public static int static_a;


        //static functions
        public void Display()
        {
            Console.WriteLine(a);
            Console.WriteLine(static_a);
            Console.WriteLine("disp");
        }

        //create a static method to access the method 
        //without creating an object of the class
        public static void static_Display()
        {
            //can only access static members directly.
            //Console.WriteLine(a);
            Console.WriteLine(static_a);
            Console.WriteLine("static disp");
        }

        //static properties
        //single copy with validations
        private static int static_prop1;
        public static int static_Prop1
        {
            get { return static_prop1; }
            set { static_prop1 = value; }
        }

        //implicitly private
        //cannot be called
        //cannot have params, therefore cannot be overloaded
        static Class1()
        {
            //used to initialise static members
            static_a = 100;
        }
        public Class1()
        {

        }

    }
    public static class StaticClass
    {
        //can only have static members
        //cannot be instantiated
        //cannot be used as a base class
    }


}
