﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lambda
{
    class Program
    {
        static void Main()
        {
            Func<int, int> objDel = new Func<int, int>(GetDouble);
            Console.WriteLine(objDel(10));

            Func<int, int> objDel2 = delegate(int i){return i * 2;};
            Console.WriteLine(objDel2(10));

            Func<int, int> objDel3 = i => i * 2;
            Console.WriteLine(objDel3(10));

            Func<int, bool> objDel4 = i => i % 2 == 0;
            Console.WriteLine(objDel4(10));

            Func<Employee, bool> objDel5 = emp => emp.Basic >10000;
            Console.WriteLine(objDel4(10));

            Func<int, int,int> objDel6 = (a,b) =>a+b;
            Console.WriteLine(objDel6(10,20));
            
            //DateTime.Now.ToLongTimeString()
            Func<string> objDel7 = () => DateTime.Now.ToLongTimeString();
            Console.WriteLine(objDel7());

            Func<int, int, int> objDel8 = (a, b) => { if (a > b) return a; else return b; };
            Console.WriteLine(objDel8(10, 20));

            Console.ReadLine();

        }

        static int GetDouble(int i)
        {
            return i * 2;
        }
    }
    class Employee
    {
        public decimal Basic { get; set; }
        public string Name { get; set; }

    }
}
