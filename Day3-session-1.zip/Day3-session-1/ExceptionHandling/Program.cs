﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExceptionHandling
{
    class Program
    {
        static void Main1()
        {
            Class1 o = new Class1();
            try
            {
                o = null;
                int i;
                i = Convert.ToInt32(Console.ReadLine());
                o.P1 = 1000 / i;
            }
            catch
            {
                Console.WriteLine("Exception handled here");
            }
            Console.ReadLine();
        }
        static void Main()
        {
            Class1 o = new Class1();
            try
            {
                o = null;
                int i;
                i = Convert.ToInt32(Console.ReadLine());
                o.P1 = 1000 / i;
            }
            catch (NullReferenceException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (FormatException ex)
            {
                Console.WriteLine("Exception handled here");
            }
            catch (DivideByZeroException ex)
            {
                Console.WriteLine("Exception handled here");
            }
            Console.ReadLine();
        }
    }

    public class Class1
    {
        private int p1;

        public int P1
        {
            get { return p1; }
            set { p1 = value; }
        }

    }
}
