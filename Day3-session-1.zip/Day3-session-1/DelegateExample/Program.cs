﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DelegateExample
{
    //step1 : create a delegate class having the same signature as method to call
    public delegate void Del1();
    public delegate int DelAdd(int a, int b);
    class Program
    {
        static void Main1()
        {
            //step 2 : create obj of delegate class, passing func name as parameter
            Del1 objDel = new Del1(Display);
            //step3: call func using delegate object
            objDel();
            Console.ReadLine();
        }
        static void Main2()
        {
            Del1 objDel = new Del1(Display);
            objDel();
            Console.WriteLine();
            objDel = new Del1(Show);
            objDel();

            Console.ReadLine();
        }
        static void Main3()
        {
            //using multicast delegates. 
            //i.e. delegate object points to multiple functions at the same time
            Del1 objDel = (Del1)Delegate.Combine(new Del1(Display), new Del1(Show));
            objDel();
            Console.WriteLine();
            objDel();

            Console.ReadLine();
        }
        static void Main4()
        {
            Del1 objDel = (Del1)Delegate.Combine(new Del1(Display), new Del1(Show), new Del1(Display));
            objDel();

            Console.WriteLine();
            //objDel = (Del1)Delegate.Remove(objDel, new Del1(Display));
            objDel = (Del1)Delegate.RemoveAll(objDel, new Del1(Display));
            objDel();

            Console.ReadLine();
        }
        static void Main5()
        {
            //Del1 objDel = new Del1(Display);
            Del1 objDel = Display;
            objDel += Show;
            objDel();

            Console.WriteLine();
            objDel -= Show;
            objDel();

            Console.ReadLine();
        }

        static void Main()
        {
            DelAdd objDel = Add;
            Console.WriteLine(objDel(5, 2));
            Class1 o = new Class1();
            objDel = o.Add;
            Console.WriteLine(objDel(15, 22));
            Console.ReadLine();
        }
        static int Add(int a, int b)
        {
            return a + b;
        }
        static void Display()
        {
            Console.WriteLine("Display");
        }
        static void Show()
        {
            Console.WriteLine("Show");
        }
    }
    public class Class1
    {
        public int Add(int a, int b)
        {
            return a + b;
        }

    }

}
