﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Generic
{
    public class SwapProg<T>
    {
        public void swap(ref T a,ref T b)
        {
            T temp;
            temp = a;
            a = b;
            b = temp;
        }
    }
    public class Program
    {
        static void Main()
        {
            int a=100;
            int b=200;

            Console.WriteLine("<<-------------INTEGER------------->>");
            SwapProg<int> o = new SwapProg<int>();
            Console.WriteLine("Before Swapping-->>" + a + "\t" + b);
            o.swap(ref a,ref b);
            Console.WriteLine("Äfter Swapping-->>" + a + "\t" + b);
            String s = "komal";
            String s1 = "Nikam";

            Console.WriteLine("<<-------------STRING------------->>");
            SwapProg<String> o1 = new SwapProg<string>();
            Console.WriteLine("Before Swapping-->>" + s + "\t" + s1);
            o1.swap(ref s, ref s1);
            Console.WriteLine("Äfter Swapping-->>" + s + "\t" + s1);
            Console.ReadLine();
        }
    }
}
