﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EventHandling
{
    class AnnonimousFunction
    {
        static void Main1()
        {
            //Action o = new Action(Display);
            //Action o = Display;

            Action o = delegate()
        {
            Console.WriteLine("Hello");
        };
            o();
        }

        //static void Display()
        //{
        //    Console.WriteLine("Hello");
        //}

    }
}

namespace EventHandling1
{
    class AnnonimousFunction
    {
        static void Main()
        {
            //Func<int, int, int> f = new Func<int, int, int>(Addition);
            //Console.WriteLine("Addition-->>" + f(10, 20)); 

            //Func<int, int, int> f = Addition;
            //Console.WriteLine("Addition-->>"+f(10, 20));       
 
            Func<int,int,int> f=delegate(int a,int b)
        {
            return a + b;
        };
            Console.WriteLine("Addition-->>"+f(10,20));
        }

       //static int Addition(int a,int b)
       // {
       //     return a + b;
       // }

    }
}


