﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DelegateDemo
{

  public delegate int DelSum(int a,int b);

    class delegates1
    {
       
        static void Main23(string[] args)
        {
           
            Class1 c = new Class1();
            DelSum d = c.Sum;
            Console.WriteLine("Sum"+ d(10, 20));
        }
    }
    public class Class1
    {
        public int Sum(int a, int b)
        {
            return a + b;
        }
    }
}
