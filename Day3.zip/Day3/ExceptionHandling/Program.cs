﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExceptionHandling
{
    class Program
    {
        static void Main1()
        {
            Class1 o = new Class1();
            try
            {
                o = null;
                int i;
                i = Convert.ToInt32(Console.ReadLine());
                o.P1 = 1000 / i;
            }
            catch
            {
                Console.WriteLine("Exception handled here");
            }
            Console.ReadLine();
        }
        static void Main()
        {
            Class1 o = new Class1();
            try
            {
                //o = null;
                int i;
                i = Convert.ToInt32(Console.ReadLine());
                //o.P1 = 1000 / i;
                o.P1 = i;
                Console.WriteLine("no exceptions");
            }
            //catch (ArithmeticException ex)
            catch (DivideByZeroException ex)
            {
                Console.WriteLine("Exception handled here");
            }
            catch (NullReferenceException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (FormatException ex)
            {
                Console.WriteLine("Exception handled here");
            }
            catch (InvalidP1Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                Console.WriteLine("finally");

            }
            Console.ReadLine();
        }
    }

    public class Class1
    {
        private int p1;

        public int P1
        {
            get { return p1; }
            set 
            {
                if (value < 100)
                    p1 = value;
                else
                    //Console.WriteLine();
                    //throw new Exception();
                    //throw new Exception("Invalid value for P1");
                    throw new InvalidP1Exception("Invalid P1");
            }
        }

    }

    public class InvalidP1Exception : ApplicationException
    {
        public InvalidP1Exception(string message) : base(message)
        {
        }
    }
}
