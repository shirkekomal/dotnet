﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise_Day3
{
    public class Num
    {
        public int a;
        public int b;
    }

    class Second
    {

        static void Main()
        {
            Num n = new Num();
            n.a = 100;
            n.b = 200;

            Predicate<Num> nn = Greater;
            bool b=nn(n);

            if(b)
                Console.WriteLine("First No is Greater");
            else
                Console.WriteLine("Second No is Greater");

            Console.ReadLine();
        }

        static bool Greater(Num n)
        {
            return (n.a > n.b);
        }


    }
}
